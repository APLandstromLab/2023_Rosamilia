#Analysis Code----
#1: Data Filtration and Standardization----
  #1a: Attach packages----
#Attach necessary packages
library(tidyverse)
library(data.table)
library(ggplot2)
library(extrafont)
library(ggalluvial)
library(ggforce)
library(ggpubr)
library(gridExtra)
library(pals)
library(vcfR)
library(readxl)

  #1b: Full ClinVar Pathogenicity Analysis----
GeneBank <- read.delim("FullClinVarFile")
  #1c: Summative file (cardiomyopathy)----
CM_genes <- c("TTN", "MYH7", "MYBPC3", "TNNT2", "TNNI3","TPM1", "ACTC1", "MYL2", 
              "MYL3", "TNNC1", "PKP2", "DSP", "DSG2", "DSC2", "JUP","TMEM43")
GeneBank <- filter(GeneBank, GeneSymbol %in% CM_genes)

  #1d: Comparison Gene Sets----
#Sarcomeric
Sarcomeric_genes <- c("TTN", "MYH7", "MYBPC3", "MYL2", "MYL3",   "ACTC1", 
                      "TPM1", "TNNT2", "TNNI3", "TNNC1")
GeneBank <- filter(GeneBank, GeneSymbol %in% Sarcomeric_genes)

#Desmosomal
Desmosomal_genes <- c("PKP2", "DSP", "DSG2", "DSC2", "JUP","TMEM43")
GeneBank <- filter(GeneBank, GeneSymbol %in% Desmosomal_genes)

#Autosomal Recessive
GSD_AR_genes <- c("GAA", "HFE", "ATP7B", "BTD") 
GeneBank <- filter(GeneBank, GeneSymbol %in% GSD_AR_genes)
#Pompe, hereditary hemochromocytosis, Wilson's,
#Biotinidase deficiency


#Autosomal Dominant Gene Set
AD_genes <- c("FBN1", "APC", "APOB", "LDLR", "PCSK9", "NF2", "TSC1",
              "TSC2", "COL3A1", "VHL", "TP53", "ENG", "ACVRL1", "MLH1", "MSH2")
#Marfan, FAP, Familial Hypercholesterolemia (x2), Neurofibromatosis, 
#Tuberous Sclerosis, VHL, Li-Fraumeni, Hereditary Hemorrhagic Telangiectasia (x2),
#Lynch (x2)
GeneBank <- filter(GeneBank, GeneSymbol %in% AD_genes)

  #1e: File by Gene----
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "TTN")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "MYH7")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "MYBPC3")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "MYL2")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "MYL3")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "ACTC1")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "TPM1")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "TNNT2")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "TNNI3")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "TNNC1")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "PKP2")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "DSP")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "DSG2")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "DSC2")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "JUP")
GeneBank <- GeneBank %>% filter(GeneBank$GeneSymbol == "TMEM43")
  #1f: Data Set Preparation----
#Make LastEvaluated dates into readable dates
GeneBank$Day <- substring(GeneBank$LastEvaluated, 1, 2)
GeneBank$Month <- substring(GeneBank$LastEvaluated, 4, 6)
GeneBank$MonthNum <- ifelse(GeneBank$Month == "Jan", "01", 
                            ifelse(GeneBank$Month == "Feb", "02", 
                                   ifelse(GeneBank$Month == "Mar", "03",
                                          ifelse(GeneBank$Month == "Apr", "04",
                                                 ifelse(GeneBank$Month == "May", "05",
                                                        ifelse(GeneBank$Month == "Jun", "06",
                                                               ifelse(GeneBank$Month == "Jul", "07",
                                                                      ifelse(GeneBank$Month == "Aug", "08",
                                                                             ifelse(GeneBank$Month == "Sep", "09",
                                                                                    ifelse(GeneBank$Month == "Oct", "10",
                                                                                           ifelse(GeneBank$Month == "Nov", "11",
                                                                                                  ifelse(GeneBank$Month == "Dec", "12", 0))))))))))))
GeneBank$LastEvaluated <- paste(GeneBank$MonthNum, "/", GeneBank$Day, "/", GeneBank$Year)
GeneBank$LastEvaluated <- str_replace_all(GeneBank$LastEvaluated, fixed(" "), "")
GeneBank$LastEvaluated <- as.Date(GeneBank$LastEvaluated, "%m/%d/%Y")
GeneBank <- GeneBank %>% select(-Day, -Month, -MonthNum)

#Standardize the ClinicalSignificance naming using the a priori scheme
GeneBankfilt <- GeneBank
GeneBankfilt$ClinicalSignificance <- 
  ifelse(GeneBankfilt$ClinicalSignificance == "Benign;Uncertain significance", "Conflicting interpretations of pathogenicity",
  ifelse(GeneBankfilt$ClinicalSignificance == "Uncertain significance;Benign", "Conflicting interpretations of pathogenicity", 
  ifelse(GeneBankfilt$ClinicalSignificance == "Likely benign;Uncertain significance", "Conflicting interpretations of pathogenicity", 
  ifelse(GeneBankfilt$ClinicalSignificance == "Uncertain significance;Likely benign", "Conflicting interpretations of pathogenicity",
  ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Uncertain significance", "Conflicting interpretations of pathogenicity", 
  ifelse(GeneBankfilt$ClinicalSignificance == "Uncertain significance;Likely pathogenic", "Conflicting interpretations of pathogenicity",
  ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;Uncertain significance", "Conflicting interpretations of pathogenicity",        
  ifelse(GeneBankfilt$ClinicalSignificance == "Uncertain significance;Pathogenic", "Conflicting interpretations of pathogenicity",     
  ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Benign", "Conflicting interpretations of pathogenicity",
  ifelse(GeneBankfilt$ClinicalSignificance == "Benign;Likely pathogenic", "Conflicting interpretations of pathogenicity",     
  ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;Benign", "Conflicting interpretations of pathogenicity",
  ifelse(GeneBankfilt$ClinicalSignificance == "Benign;Pathogenic", "Conflicting interpretations of pathogenicity",    
  ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Likely benign", "Conflicting interpretations of pathogenicity",   
  ifelse(GeneBankfilt$ClinicalSignificance == "Likely benign;Likely pathogenic", "Conflicting interpretations of pathogenicity",
  ifelse(GeneBankfilt$ClinicalSignificance == "Likely benign;Pathogenic", "Conflicting interpretations of pathogenicity",
  ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;Likely Benign", "Conflicting interpretations of pathogenicity",
  ifelse(GeneBankfilt$ClinicalSignificance == "Likely benign;Benign", "Benign/Likely benign",
                                                                                                                         ifelse(GeneBankfilt$ClinicalSignificance == "Benign;Likely benign", "Benign/Likely benign",
                                                                                                                                ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Pathogenic", "Pathogenic/Likely pathogenic",
                                                                                                                                       ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;Likely pathogenic", "Pathogenic/Likely pathogenic",
                                                                                                                                              ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic", "Pathogenic",
                                                                                                                                                     ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;risk factor", "Pathogenic",
                                                                                                                                                            ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;not provided", "Pathogenic",
                                                                                                                                                                   ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;not provided;risk factor", "Pathogenic",
                                                                                                                                                                          ifelse(GeneBankfilt$ClinicalSignificance == "risk factor", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                 ifelse(GeneBankfilt$ClinicalSignificance == "not provided;risk factor", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                        ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic", "Likely pathogenic",
                                                                                                                                                                                               ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;not provided", "Likely pathogenic",
                                                                                                                                                                                                      ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;not provided;risk factor", "Likely pathogenic",
                                                                                                                                                                                                             ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;risk factor", "Likely pathogenic",
                                                                                                                                                                                                                    ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Pathogenic;risk factor", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                                                           ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Pathogenic;not provided", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                                                                  ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Pathogenic;not provided;risk factor", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                                                                         ifelse(GeneBankfilt$ClinicalSignificance == "Uncertain significance", "Uncertain significance",
                                                                                                                                                                                                                                                ifelse(GeneBankfilt$ClinicalSignificance == "Uncertain significance;not provided", "Uncertain significance",
                                                                                                                                                                                                                                                       ifelse(GeneBankfilt$ClinicalSignificance == "association", "Uncertain significance",
                                                                                                                                                                                                                                                              ifelse(GeneBankfilt$ClinicalSignificance == "Likely benign", "Likely benign",
                                                                                                                                                                                                                                                                     ifelse(GeneBankfilt$ClinicalSignificance == "Likely benign;not provided", "Likely benign",
                                                                                                                                                                                                                                                                            ifelse(GeneBankfilt$ClinicalSignificance == "Benign", "Benign",
                                                                                                                                                                                                                                                                                   ifelse(GeneBankfilt$ClinicalSignificance == "Benign;not provided", "Benign",
                                                                                                                                                                                                                                                                                          ifelse(GeneBankfilt$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "Conflicting interpretations of pathogenicity",
                                                                                                                                                                                                                                                                                                 ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic/Likely pathogenic", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                                                                                                                                        ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic/Likely pathogenic, risk factor", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                                                                                                                                               ifelse(GeneBankfilt$ClinicalSignificance == "Benign/Likely benign", "Benign/Likely benign", 
                                                                                                                                                                                                                                                                                                                      ifelse(GeneBankfilt$ClinicalSignificance == "not provided", "not provided",
                                                                                                                                                                                                                                                                                                                             ifelse(GeneBankfilt$ClinicalSignificance == "-", "-",
                                                                                                                                                                                                                                                                                                                                    ifelse(GeneBankfilt$ClinicalSignificance == "no interpretation for the single variant", "-",
                                                                                                                                                                                                                                                                                                                                           ifelse(GeneBankfilt$ClinicalSignificance == "not reported for simple variant", "-", 
                                                                                                                                                                                                                                                                                                                                                  ifelse(GeneBankfilt$ClinicalSignificance == "Affects", "-",
                                                                                                                                                                                                                                                                                                                                                         ifelse(GeneBankfilt$ClinicalSignificance == "drug response", "-",
                                                                                                                                                                                                                                                                                                                                                                "Conflicting interpretations of pathogenicity"))))))))))))))))))))))))))))))))))))))))))))))))))

#Code Review Status By ClinVar Criteria of Stars
GeneBankfilt$ReviewStatus <- 
  ifelse(GeneBankfilt$ReviewStatus == "practice guideline", "4",
         ifelse(GeneBankfilt$ReviewStatus == "reviewed by expert panel", "3", 
                ifelse(GeneBankfilt$ReviewStatus == "reviewed by professional society", "3", 
                       ifelse(GeneBankfilt$ReviewStatus == "criteria provided, multiple submitters, no conflicts", "2", 
                              ifelse(GeneBankfilt$ReviewStatus == "criteria provided, conflicting interpretations", "1",
                                     ifelse(GeneBankfilt$ReviewStatus == "criteria provided, single submitter", "1", 
                                            ifelse(GeneBankfilt$ReviewStatus == "classified by multiple submitters", "1",
                                                   ifelse(GeneBankfilt$ReviewStatus == "classified by single submitter", "1", 
                                                          ifelse(GeneBankfilt$ReviewStatus == "no assertion criteria provided", "0",
                                                                 ifelse(GeneBankfilt$ReviewStatus == "no assertion for the individual variant", "0",
                                                                        ifelse(GeneBankfilt$ReviewStatus == "no assertion criteria for the single variant", "0",
                                                                               ifelse(GeneBankfilt$ReviewStatus == "no interpretation for the single variant", "0", 
                                                                                      ifelse(GeneBankfilt$ReviewStatus == "not classified by submitter", "0", 
                                                                                             ifelse(GeneBankfilt$ReviewStatus == "no assertion provided", "0", 
                                                                                                    ifelse(GeneBankfilt$ReviewStatus == "-", "-",
                                                                                                           "***")))))))))))))))

GeneBankfilt$ReviewStatus <- as.numeric(GeneBankfilt$ReviewStatus)


GeneBankfilt$ReviewStatusHighest <- 
  ifelse(GeneBankfilt$ReviewStatusHighest == "practice guideline", "4",
         ifelse(GeneBankfilt$ReviewStatusHighest == "reviewed by expert panel", "3", 
                ifelse(GeneBankfilt$ReviewStatusHighest == "reviewed by professional society", "3", 
                       ifelse(GeneBankfilt$ReviewStatusHighest == "criteria provided, multiple submitters, no conflicts", "2", 
                              ifelse(GeneBankfilt$ReviewStatusHighest == "criteria provided, conflicting interpretations", "1",
                                     ifelse(GeneBankfilt$ReviewStatusHighest == "criteria provided, single submitter", "1", 
                                            ifelse(GeneBankfilt$ReviewStatusHighest == "classified by multiple submitters", "1",
                                                   ifelse(GeneBankfilt$ReviewStatusHighest == "classified by single submitter", "1", 
                                                          ifelse(GeneBankfilt$ReviewStatusHighest == "no assertion criteria provided", "0",
                                                                 ifelse(GeneBankfilt$ReviewStatusHighest == "no assertion for the individual variant", "0",
                                                                        ifelse(GeneBankfilt$ReviewStatusHighest == "no assertion criteria for the single variant", "0",
                                                                               ifelse(GeneBankfilt$ReviewStatusHighest == "no interpretation for the single variant", "0", 
                                                                                      ifelse(GeneBankfilt$ReviewStatusHighest == "not classified by submitter", "0", 
                                                                                             ifelse(GeneBankfilt$ReviewStatusHighest == "no assertion provided", "0", 
                                                                                                    ifelse(GeneBankfilt$ReviewStatusHighest == "-", "-",
                                                                                                           "***")))))))))))))))

GeneBankfilt <- GeneBankfilt %>% filter(GeneBankfilt$ClinicalSignificance != "-")

#Recode Submitters
GeneBankfilt$Submitter <- 
  ifelse(GeneBankfilt$Submitter == "OMIM", "Academic",
         ifelse(GeneBankfilt$Submitter == "Baylor Genetics", "Academic",
                ifelse(GeneBankfilt$Submitter == "Laboratory of Genetics and Genomics,Cincinnati Children's Hospital Medical Center", "Academic",
                       ifelse(GeneBankfilt$Submitter == "Emory Genetics Laboratory,Emory University", "Academic",
                              ifelse(GeneBankfilt$Submitter == "Genetic Services Laboratory, University of Chicago", "Academic",
                                     ifelse(GeneBankfilt$Submitter == "Evidence-based Network for the Interpretation of Germline Mutant Alleles (ENIGMA)", "Academic",
                                            ifelse(GeneBankfilt$Submitter == "ISCA site 1", "Academic",
                                                   ifelse(GeneBankfilt$Submitter == "ISCA site 4", "Academic",
                                                          ifelse(GeneBankfilt$Submitter == "Center for Pediatric Genomic Medicine,Children's Mercy Hospital and Clinics", "Academic",
                                                                 ifelse(GeneBankfilt$Submitter == "ARUP Laboratories, Molecular Genetics and Genomics, ARUP Laboratories", "Academic",
                                                                        ifelse(GeneBankfilt$Submitter == "Clinical Biochemistry Laboratory, Health Services Laboratory", "Academic",
                                                                               ifelse(GeneBankfilt$Submitter == "ITMI", "Academic",
                                                                                      ifelse(GeneBankfilt$Submitter == "LDLR-LOVD, British Heart Foundation", "Academic",
                                                                                             ifelse(GeneBankfilt$Submitter == "ARUP", "Academic",
                                                                                                    ifelse(GeneBankfilt$Submitter == "ARUP Institute,ARUP Laboratories", "Academic",
                                                                                                           ifelse(GeneBankfilt$Submitter == "Research and Development, ARUP Laboratories", "Academic",
                                                                                                                  ifelse(GeneBankfilt$Submitter == "Division of Genomic Diagnostics,The Children's Hospital of Philadelphia", "Academic",
                                                                                                                         ifelse(GeneBankfilt$Submitter == "Gharavi Laboratory,Columbia University", "Academic",
                                                                                                                                ifelse(GeneBankfilt$Submitter == "Wong Mito Lab, Molecular and Human Genetics, Baylor College of Medicine", "Academic",
                                                                                                                                       ifelse(GeneBankfilt$Submitter == "ARUP Laboratories, Molecular Genetics and Genomics", "Academic",
                                                                                                                                              ifelse(GeneBankfilt$Submitter == "RettBASE", "Academic",
                                                                                                                                                     ifelse(GeneBankfilt$Submitter == "University of Washington Department of Laboratory Medicine,University of Washington", "Academic",
                                                                                                                                                            ifelse(GeneBankfilt$Submitter == "Invitae", "Private",
                                                                                                                                                                   ifelse(GeneBankfilt$Submitter == "Invitae,", "Private",
                                                                                                                                                                          ifelse(GeneBankfilt$Submitter == "Baylor Maraca Genetics Laboratories", "Private",
                                                                                                                                                                                 ifelse(GeneBankfilt$Submitter == "GeneDx", "Private",
                                                                                                                                                                                        ifelse(GeneBankfilt$Submitter == "EGL Genetic Diagnostics,Eurofins Clinical Diagnostics", "Private",
                                                                                                                                                                                               ifelse(GeneBankfilt$Submitter == "Color", "Private",
                                                                                                                                                                                                      ifelse(GeneBankfilt$Submitter == "Athena Diagnostics Inc", "Private",
                                                                                                                                                                                                             ifelse(GeneBankfilt$Submitter == "Integrated Genetics/Laboratory Corporation of America", "Private",
                                                                                                                                                                                                                    ifelse(GeneBankfilt$Submitter == "Quest Diagnostics Nichols Institute San Juan Capistrano", "Private",
                                                                                                                                                                                                                           ifelse(GeneBankfilt$Submitter == "CeGaT Praxis fuer Humangenetik Tuebingen", "Private",
                                                                                                                                                                                                                                  ifelse(GeneBankfilt$Submitter == "Lineagen Inc.", "Private",
                                                                                                                                                                                                                                         ifelse(GeneBankfilt$Submitter == "Illumina Clinical Services Laboratory,Illumina", "Private",
                                                                                                                                                                                                                                                ifelse(GeneBankfilt$Submitter == "Counsyl", "Private",
                                                                                                                                                                                                                                                       ifelse(GeneBankfilt$Submitter == "Laboratory for Molecular Medicine,Partners HealthCare Personalized Medicine", "Private",
                                                                                                                                                                                                                                                              ifelse(GeneBankfilt$Submitter == "Ambry Genetics", "Private",
                                                                                                                                                                                                                                                                     ifelse(GeneBankfilt$Submitter == "International Society for Gastrointestinal Hereditary Tumours (InSiGHT)", "Private",
                                                                                                                                                                                                                                                                            ifelse(GeneBankfilt$Submitter == "InSiGHT", "Private",
                                                                                                                                                                                                                                                                                   ifelse(GeneBankfilt$Submitter == "Blueprint Genetics", "Private",
                                                                                                                                                                                                                                                                                          ifelse(GeneBankfilt$Submitter == "Fulgent Genetics,Fulgent Genetics", "Private",
                                                                                                                                                                                                                                                                                                 ifelse(GeneBankfilt$Submitter == "LabCorp", "Private",
                                                                                                                                                                                                                                                                                                        ifelse(GeneBankfilt$Submitter == "Laboratory Corporation of America", "Private",
                                                                                                                                                                                                                                                                                                               ifelse(GeneBankfilt$Submitter == "Praxis fuer Humangenetik Tuebingen,", "Private",
                                                                                                                                                                                                                                                                                                                      ifelse(GeneBankfilt$Submitter == "Praxis fuer Humangenetik Tuebingen", "Private",     
                                                                                                                                                                                                                                                                                                                             ifelse(GeneBankfilt$Submitter == "GeneReviews", "Governmental",
                                                                                                                                                                                                                                                                                                                                    ifelse(GeneBankfilt$Submitter == "Sharing Clinical Reports Project (SCRP)", "Governmental",
                                                                                                                                                                                                                                                                                                                                           ifelse(GeneBankfilt$Submitter == "Biesecker Lab/Human Development Section,National Institutes of Health", "Governmental",
                                                                                                                                                                                                                                                                                                                                                  "small"))))))))))))))))))))))))))))))))))))))))))))))))

GeneBankfilt_subtbl <- data.table(table(GeneBankfilt$Submitter))

#Subset, unique rows into a new data frame "GeneBankdt"
GeneBankdt <- data.table(distinct(GeneBankfilt))
GeneBankdt <- GeneBankdt %>% select(AlleleID, GeneSymbol, ClinicalSignificance, 
                                    LastEvaluated, Year)
GeneBankdt$ID <- seq.int(nrow(GeneBankdt))

#Order by Allele and Date
GeneBankdt <- GeneBankdt[with(GeneBankdt, 
                              order(AlleleID, LastEvaluated))]

#Remove years beyond 2021 (incomplete or error)
GeneBankdt <- GeneBankdt %>%
  filter(GeneBankdt$Year < 2022)

#Create Numeric Variables
GeneBankfilt$ReviewStatusHighest <- as.numeric(GeneBankfilt$ReviewStatusHighest)
GeneBankfilt$ReviewStatus <- as.numeric(GeneBankfilt$ReviewStatus)
GeneBankfilt1 <- GeneBankfilt
GeneBankfilt <- GeneBankfilt[complete.cases(GeneBankfilt),]

#2: Necessary Data Sets----
  #2a: All Reevaluations----
#How many variants are Reevaluated?
names(GeneBankdt) [1] <- "AlleleID"
eval_freq <- data.table(table (GeneBankdt$AlleleID))
#Create a data frame with only variants that were Reevaluated
reeval <- eval_freq %>%
  filter (N > 1)
names(reeval) [1] <- "AlleleID"
reeval <- reeval %>%
  mutate(AlleleID = as.numeric(AlleleID))
#Merge the table containing only variantss that changed clinical significance
#with the original data frame, which includes LastEvaluated, in order to create
#a new data frame with only the SNPs that changed AND all of the pertinent information
#about them
GeneBank.reeval <- merge(x = GeneBankdt, y = reeval, by = "AlleleID", all.x = TRUE)
GeneBank.reeval <- GeneBank.reeval [complete.cases(GeneBank.reeval),]
#How many SNPs are there here?
n_distinct(GeneBank.reeval$AlleleID)

  #2b: All variants that change clinical significance----
#Now create a data frame that only contains SNPs that changed clinical significance
#First, create a new data frame that removes the LastEvaluated variable and then
#removes repeats
GeneBankfiltnodate <- GeneBankdt %>% select(AlleleID, GeneSymbol, ClinicalSignificance)
GeneBank.2nodate <- distinct(GeneBankfiltnodate)
GeneBankdtnodate <- data.table(GeneBank.2nodate)
#Second, create a frequency table. Since repeats were eliminated and the only
#variables that change are now AlleleID and ClinicalSignificance, only SNPs that
#changed clinical significance will show up more than once
change_freq.1 <- table (GeneBankdtnodate$AlleleID)
change_freq <- data.table(change_freq.1)
#Create a new data frame "changed" that only contains SNPs that changed clinical 
#significance values at least once
changed <- change_freq %>%
  filter (N > 1)
names(changed) [1] <- "AlleleID"
changed <- changed %>%
  mutate(AlleleID = as.numeric(AlleleID))
#Third, merge the table containing only SNPs that changed clinical significance
#with the original data frame, which includes LastEvaluated, in order to create
#a new data frame with only the SNPs that changed AND all of the pertinent information
#about them
GeneBank.changed <- merge(x = GeneBankdt, y = changed, by = "AlleleID", all.x = TRUE)
GeneBank.changed <- GeneBank.changed [complete.cases(GeneBank.changed),]
n_distinct(GeneBank.changed$AlleleID)
#Of the SNPs that are Reevaluated, what proportion of them change clinical significance?
n_distinct(GeneBank.changed$AlleleID)/n_distinct(GeneBank.reeval$AlleleID)

  #2c: Variants that have a clinically significant change-----
#How often do these changes represent a change that is clinically meaningful?
#(ex. pathogenic <--> benign or uncertain)
GeneBank_sigind <- GeneBank.changed %>% select(AlleleID, ClinicalSignificance)
#Find and replace all "pathogenic" with "1" and all other with "0"
GeneBank_sigind$ClinicalSignificance <- 
  ifelse(GeneBank.changed$ClinicalSignificance == "Pathogenic/Likely pathogenic", "2",
         ifelse(GeneBank.changed$ClinicalSignificance == "Likely pathogenic", "2", 
                ifelse(GeneBank.changed$ClinicalSignificance == "Pathogenic", "2", 
                       ifelse(GeneBank.changed$ClinicalSignificance == "Uncertain significance", "1",
                              ifelse(GeneBank.changed$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "1", "0")))))
GeneBank_sigind <- distinct(GeneBank_sigind)

#Create a new dataframe with only SNPs that changed at some point AND were
#were pathogenic or likely pathogenic at some point
GeneBanksig <- GeneBank_sigind %>% filter(ClinicalSignificance == 1)
#Create a dataframe that contains only the SNPs that changed at some point in
#a clinically significant way
GeneBank_sigindfreq <- data.table(table(GeneBank_sigind$AlleleID))
GeneBank_sigindfreq <- GeneBank_sigindfreq %>% filter(N > 1)
names(GeneBank_sigindfreq) [1] <- "AlleleID"
GeneBank_sigindfreq <- GeneBank_sigindfreq %>% mutate(AlleleID = as.numeric(AlleleID))
GeneBank_sigchange <- merge (x = GeneBank.changed, y = GeneBank_sigindfreq, by = "AlleleID")
GeneBank_sigchange <- GeneBank_sigchange %>% select(ID, AlleleID, GeneSymbol, 
                                                    ClinicalSignificance, LastEvaluated, Year)
GeneBank_sigchange$ID2 <- seq.int(nrow(GeneBank_sigchange))
#Now count the number of SNPs in this data frame
n_distinct(GeneBank_sigchange$AlleleID)
#Print all of the relevant counts and calculations
n_distinct(GeneBankdt$AlleleID)
n_distinct(GeneBank.reeval$AlleleID)
n_distinct(GeneBank.changed$AlleleID)
n_distinct(GeneBank.changed$AlleleID)/n_distinct(GeneBank.reeval$AlleleID)
n_distinct(GeneBank_sigchange$AlleleID)

#Create some meta-data around those SNPs that have changed in a clinically meaningful way

GeneBank_sigchange_confind <- GeneBank_sigchange %>%
  select(ID2, ClinicalSignificance)
GeneBank_sigchange_confind$ClinicalSignificance <- 
  ifelse(GeneBank_sigchange_confind$ClinicalSignificance == "Pathogenic", "2",
         ifelse(GeneBank_sigchange_confind$ClinicalSignificance == "Benign", "2",    
                ifelse(GeneBank_sigchange_confind$ClinicalSignificance == "Likely pathogenic", "1", 
                       ifelse(GeneBank_sigchange_confind$ClinicalSignificance == "Pathogenic/Likely pathogenic", "1", 
                              ifelse(GeneBank_sigchange_confind$ClinicalSignificance == "Likely benign", "1", 
                                     ifelse(GeneBank_sigchange_confind$ClinicalSignificance == "Benign/Likely benign", "1",
                                            ifelse(GeneBank_sigchange_confind$ClinicalSignificance == "Uncertain significance", "0",
                                                   ifelse(GeneBank_sigchange_confind$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "0", "0"))))))))
GeneBank_sigchange_confind <- GeneBank_sigchange_confind %>%
  mutate(ID2 = as.numeric(ID2))
names (GeneBank_sigchange_confind) [2] <- "Significance_Confidence_Indicator"
GeneBank_sigchange <- merge (x = GeneBank_sigchange, y = GeneBank_sigchange_confind, by = "ID2")
GeneBank_sigchange <- GeneBank_sigchange %>% 
  mutate(Significance_Confidence_Indicator = as.numeric(Significance_Confidence_Indicator))
GeneBank_sigchange_levelind <- GeneBank_sigchange %>%
  select(ID2, ClinicalSignificance)
GeneBank_sigchange_levelind$ClinicalSignificance <- 
  ifelse(GeneBank_sigchange_levelind$ClinicalSignificance == "Pathogenic", "3",
         ifelse(GeneBank_sigchange_levelind$ClinicalSignificance == "Benign", "-3",    
                ifelse(GeneBank_sigchange_levelind$ClinicalSignificance == "Likely pathogenic", "1", 
                       ifelse(GeneBank_sigchange_levelind$ClinicalSignificance == "Pathogenic/Likely pathogenic", "2", 
                              ifelse(GeneBank_sigchange_levelind$ClinicalSignificance == "Likely benign", "-1", 
                                     ifelse(GeneBank_sigchange_levelind$ClinicalSignificance == "Benign/Likely benign", "-2",
                                            ifelse(GeneBank_sigchange_levelind$ClinicalSignificance == "Uncertain significance", "0",
                                                   ifelse(GeneBank_sigchange_levelind$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "0", "0"))))))))
GeneBank_sigchange_levelind <- GeneBank_sigchange_levelind %>%
  mutate(ID2 = as.numeric(ID2))
names (GeneBank_sigchange_levelind) [2] <- "Significance_Level_Indicator"
GeneBank_sigchange <- merge (x = GeneBank_sigchange, y = GeneBank_sigchange_levelind, by = "ID2")
GeneBank_sigchange <- GeneBank_sigchange %>% 
  mutate(Significance_Level_Indicator = as.numeric(Significance_Level_Indicator))


  #2d: First Evaluations of Variants----
#Create a data frame with only the first evaluation of every variant
GeneBank_dt_confind <- GeneBankdt %>%
  select(ID, ClinicalSignificance)
GeneBank_dt_confind$ClinicalSignificance <- 
  ifelse(GeneBank_dt_confind$ClinicalSignificance == "Pathogenic", "2",
         ifelse(GeneBank_dt_confind$ClinicalSignificance == "Benign", "2",    
                ifelse(GeneBank_dt_confind$ClinicalSignificance == "Likely pathogenic", "1", 
                       ifelse(GeneBank_dt_confind$ClinicalSignificance == "Pathogenic/Likely pathogenic", "1", 
                              ifelse(GeneBank_dt_confind$ClinicalSignificance == "Likely benign", "1", 
                                     ifelse(GeneBank_dt_confind$ClinicalSignificance == "Benign/Likely benign", "1",
                                            ifelse(GeneBank_dt_confind$ClinicalSignificance == "Uncertain significance", "0",
                                                   ifelse(GeneBank_dt_confind$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "0", "0"))))))))
names(GeneBank_dt_confind) [1] <- "ID"
names(GeneBank_dt_confind) [2] <- "Significance_Confidence_Indicator"
GeneBank_dt_confind <- GeneBank_dt_confind %>%
  mutate(ID = as.numeric(ID))
GeneBankdt <- merge (x = GeneBankdt, y = GeneBank_dt_confind, by = "ID")
GeneBankdt <- GeneBankdt %>% 
  mutate(Significance_Confidence_Indicator = as.numeric(Significance_Confidence_Indicator))
GeneBank_dt_levelind <- GeneBankdt %>%
  select(ID, ClinicalSignificance)
GeneBank_dt_levelind$ClinicalSignificance <- 
  ifelse(GeneBank_dt_levelind$ClinicalSignificance == "Pathogenic", "3",
         ifelse(GeneBank_dt_levelind$ClinicalSignificance == "Benign", "-3",    
                ifelse(GeneBank_dt_levelind$ClinicalSignificance == "Likely pathogenic", "1", 
                       ifelse(GeneBank_dt_levelind$ClinicalSignificance == "Pathogenic/Likely pathogenic", "2", 
                              ifelse(GeneBank_dt_levelind$ClinicalSignificance == "Likely benign", "-1", 
                                     ifelse(GeneBank_dt_levelind$ClinicalSignificance == "Benign/Likely benign", "-2",
                                            ifelse(GeneBank_dt_levelind$ClinicalSignificance == "Uncertain significance", "0",
                                                   ifelse(GeneBank_dt_levelind$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "0", "0"))))))))
names(GeneBank_dt_levelind) [1] <- "ID"
names(GeneBank_dt_levelind) [2] <- "Significance_Level_Indicator"
GeneBank_dt_confind <- GeneBank_dt_confind %>%
  mutate(ID = as.numeric(ID))
GeneBankdt <- merge (x = GeneBankdt, y = GeneBank_dt_levelind, by = "ID")
GeneBankdt <- GeneBankdt %>% 
  mutate(Significance_Level_Indicator = as.numeric(Significance_Level_Indicator))
GeneBankdt_first <- GeneBankdt %>% select(ID, AlleleID, LastEvaluated)
GeneBankdt_first <- GeneBankdt_first %>% group_by(AlleleID) %>%
  filter(LastEvaluated == min(LastEvaluated))
GeneBankdt_first <- GeneBankdt_first %>% select(ID, AlleleID)
GeneBankdt_firsteval <- merge(x = GeneBankdt, y = GeneBankdt_first, by = "ID")
names(GeneBankdt_firsteval) [2] <- "AlleleID"
GeneBankdt_firsteval <- GeneBankdt_firsteval %>% mutate(AlleleID = as.numeric(AlleleID))
GeneBankdt_firsteval <- GeneBankdt_firsteval %>% select(ID, AlleleID, GeneSymbol,
                                                        ClinicalSignificance, LastEvaluated, Year, Significance_Confidence_Indicator,
                                                        Significance_Level_Indicator)
GeneBankdt_firsteval <- GeneBankdt_firsteval [complete.cases(GeneBankdt_firsteval),]

  #2e: Reevaluations of Variants----
#Create a data frame that has everything BUT the first eval
GeneBankdt_nofirst <- setdiff(GeneBankdt, GeneBankdt_firsteval)
GeneBankdt_nofirst <- GeneBankdt_nofirst [complete.cases(GeneBankdt_nofirst),]

  #2f: Evaluation Leading to Significant Change----
#Create a data frame that contains only variants that significantly changed on the evaluation when they changed
#Now create a data frame that only contains SNPs that changed clinical significance
#First, create a new data frame that removes the LastEvaluated variable and then
#removes repeats
GeneBankfiltnodate <- GeneBankdt %>% select(AlleleID, GeneSymbol, ClinicalSignificance)
GeneBank.2nodate <- distinct(GeneBankfiltnodate)
GeneBankdtnodate <- data.table(GeneBank.2nodate)
#Second, create a frequency table. Since repeats were eliminated and the only
#variables that change are now AlleleID and ClinicalSignificance, only SNPs that
#changed clinical significance will show up more than once
change_freq.1 <- table (GeneBankdtnodate$AlleleID)
change_freq <- data.table(change_freq.1)
#Create a new data frame "changed" that only contains SNPs that changed clinical 
#significance values at least once
changed <- change_freq %>%
  filter (N > 1)
names(changed) [1] <- "AlleleID"
changed <- changed %>%
  mutate(AlleleID = as.numeric(AlleleID))
#Third, merge the table containing only SNPs that changed clinical significance
#with the original data frame, which includes LastEvaluated, in order to create
#a new data frame with only the SNPs that changed AND all of the pertinent information
#about them
GeneBank.changed <- merge(x = GeneBankdt, y = changed, by = "AlleleID", all.x = TRUE)
GeneBank.changed <- GeneBank.changed [complete.cases(GeneBank.changed),]
n_distinct(GeneBank.changed$AlleleID)
#Of the SNPs that are Reevaluated, what proportion of them change clinical significance?
n_distinct(GeneBank.changed$AlleleID)/n_distinct(GeneBank.reeval$AlleleID)

GeneBank_sigind_changeind <- GeneBank_sigchange %>% select(AlleleID, 
                                                           ClinicalSignificance, LastEvaluated, Year, Significance_Level_Indicator)
GeneBank_sigind_changeind$Bucket_Indicator <- 
  ifelse(GeneBank_sigchange$ClinicalSignificance == "Pathogenic/Likely pathogenic", "2",
         ifelse(GeneBank_sigchange$ClinicalSignificance == "Likely pathogenic", "2", 
                ifelse(GeneBank_sigchange$ClinicalSignificance == "Pathogenic", "2", 
                       ifelse(GeneBank_sigchange$ClinicalSignificance == "Uncertain significance", "1",
                              ifelse(GeneBank_sigchange$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "1", "0")))))
GeneBank_sigind_changeind$ID2 <- seq.int(nrow(GeneBank_sigind_changeind))
GeneBank_sigchange$ID2 <- seq.int(nrow(GeneBank_sigchange))
GeneBank_sigind_changeind <- GeneBank_sigind_changeind %>% select("ID2", "Bucket_Indicator")
GeneBank_sigchange_changeind <- merge (x=GeneBank_sigchange, y= GeneBank_sigind_changeind, by = "ID2")

GeneBank_sigchange_changeind$Bucket_Indicator <- as.numeric(GeneBank_sigind_changeind$Bucket_Indicator)
Storage1 <- data.table(numeric(length(GeneBank_sigind_changeind$Bucket_Indicator)))
for(i in 2:length(GeneBank_sigind_changeind$Bucket_Indicator)){
  if(GeneBank_sigind_changeind$Bucket_Indicator[i] != GeneBank_sigind_changeind$Bucket_Indicator[i-1]){
    Storage1 [i] <- 1
  }else{
    Storage1 [i] <- 0
  }
}
Storage1$ID2 <- seq.int(nrow(Storage1))
names(Storage1) [1] <- "ClinSig_Change_Indicator"
Storage1$ClinSig_Change_Indicator <- as.numeric(Storage1$ClinSig_Change_Indicator)
GeneBank_sigchange_changeind <- merge(x=GeneBank_sigchange_changeind, y=Storage1, by = "ID2")

GeneBank_sigind_alleleind <- GeneBank_sigchange %>% select(AlleleID, ClinicalSignificance, LastEvaluated)
GeneBank_sigind_alleleind$ID2 <- seq.int(nrow(GeneBank_sigind_alleleind))
GeneBank_sigind_alleleind <- GeneBank_sigind_alleleind %>% select("ID2", "AlleleID")

GeneBank_sigind_alleleind$AlleleID <- as.numeric(GeneBank_sigind_alleleind$AlleleID)
Storage2 <- data.table(numeric(length(GeneBank_sigind_alleleind$AlleleID)))
for(i in 2:length(GeneBank_sigind_alleleind$AlleleID)){
  if(GeneBank_sigind_alleleind$AlleleID[i] == GeneBank_sigind_alleleind$AlleleID[i-1]){
    Storage2 [i] <- 1
  }else{
    Storage2 [i] <- 0
  }
}

Storage2$ID2 <- seq.int(nrow(Storage2))
names(Storage2) [1] <- "Allele_Change_Indicator"
Storage2$Allele_Change_Indicator <- as.numeric(Storage2$Allele_Change_Indicator)
GeneBank_sigchange_changeind <- merge(x=GeneBank_sigchange_changeind, y=Storage2, by = "ID2")

GeneBank_sigchange_changeind <- GeneBank_sigchange_changeind %>%
  filter(ClinSig_Change_Indicator == 1 & Allele_Change_Indicator == 1)

  #2g: Summary Table Output for a Given Variant----
#Make a nice output
GeneBank_Output <- data.frame("Genes" = c("RYR2"), 
                              "Number_of_SNPs" = n_distinct(GeneBankdt$AlleleID), 
                              "SNPs_Reevaluated" = n_distinct(GeneBank.reeval$AlleleID), 
                              "SNPs_that_Changed_Clinical_Significance" = n_distinct(GeneBank.changed$AlleleID), 
                              "Proportion_of_Evals_that_Resulted_in_Clinical_Significance_Change" = n_distinct(GeneBank.changed$AlleleID)/n_distinct(GeneBank.reeval$AlleleID),
                              "SNPs_with_a_Clinically_Meaningful_Change" = n_distinct(GeneBank_sigchange$AlleleID))


#3: Figure Prep Data Sets----
GeneBankdt_bygene_first <- data.table(table(GeneBankdt_firsteval$GeneSymbol, 
                                            GeneBankdt_firsteval$Year))
names(GeneBankdt_bygene_first) [1] <- "Gene"
names(GeneBankdt_bygene_first) [2] <- "Year"
names(GeneBankdt_bygene_first) [3] <- "Number_of_Variants"
#4: Other Analyses----
  #General----
#Overall quality of evidence
GeneBankfilt <- GeneBankfilt[complete.cases(GeneBankfilt),]
GeneBankfilt$ReviewStatus <- as.numeric(GeneBankfilt$ReviewStatus)
GeneBankfilt$ReviewStatusHighest <- as.numeric(GeneBankfilt$ReviewStatusHighest)
QualofEvidence <- data.table(table(GeneBankfilt$ReviewStatusHighest))
QualofEvidence$Proportion <- QualofEvidence$N/sum(QualofEvidence$N)
ggplot(QualofEvidence, aes(x = V1, y = Proportion, fill = SetID))+
  geom_bar(stat = "identity", color = "black", size = 1.5,
           position = "dodge")+
  ylab("Proportion of Variants")+
  xlab("Highest Review Quality")+
  ylim(0, 0.8)+
  scale_fill_manual(values = c("white", "red3"))+
  theme(axis.text = element_text(size = 20, family = "Arial", color = "black", face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 24, family = "Arial", face = "bold", color = "black"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "none")

#Mean Evidence Quality
QualofEvidence$V1 <- as.numeric(QualofEvidence$V1)
QualofEvidence$QualProd <- QualofEvidence$V1*QualofEvidence$N
Qual_CM <- QualofEvidence %>% filter(SetID == "CM")
Qual_All <- QualofEvidence %>% filter(SetID == "All")
sum(Qual_CM$QualProd)/sum(Qual_CM$N)
sum(Qual_All$QualProd)/sum(Qual_All$N)
  
#If All ClinVar
#QualofEvidence_All <- QualofEvidence
#QualofEvidence_All$SetID <- "All"

#If CM
#QualofEvidence$SetID <- "CM"
#QualofEvidence <- rbind(QualofEvidence, QualofEvidence_All)
#QualofEvidence_tool <- data.table(
  V1 = c(4),
  N = c(0),
  Proportion = c(0),
  SetID = c("CM"))
#QualofEvidence <- rbind(QualofEvidence, QualofEvidence_tool)

QualOverall <- GeneBankfilt %>%
  summarise(MeanQuality=(mean(ReviewStatus)))

#Number of Each Submitter Type
SubTypeSum <- data.table(table(GeneBankfilt$Submitter))
barplot(SubTypeSum$N, names.arg = SubTypeSum$V1, main = "Number of each Submitter Type")

#Quality of Evidence by Submitter Type
SubmitterPerformance <- data.table(table(GeneBankfilt$Submitter, GeneBankfilt$ReviewStatus))
SubmitterPerformance$V2 <- as.numeric(SubmitterPerformance$V2)
QualbySub <- GeneBankfilt %>%
  group_by(Submitter) %>%
  summarise(MeanQuality=(mean(ReviewStatus)))
QualbySub <- QualbySub[complete.cases(QualbySub),]
barplot(QualbySub$MeanQuality, names.arg = QualbySub$Submitter)

#Description of Number of Submitters
hist(GeneBankfilt$NumberSubmitters)
MeanSubmitters <- GeneBankfilt %>%
  summarise(MeanSubs=(mean(NumberSubmitters)))

#Quality of Evidence by Number of Submitters
QualbyNumSub <- GeneBankfilt %>%
  group_by(NumberSubmitters) %>%
  summarise(MeanQuality=(mean(ReviewStatus)))
plot(QualbyNumSub$NumberSubmitters, QualbyNumSub$MeanQuality, 
     xlab = "Number of Submitters", ylab = "Mean Highest Quality of Evidence")

#Quality of Evidence by Pathogenicity Status
QualbyPath <- GeneBankfilt %>%
  group_by(ClinicalSignificance) %>%
  summarise(MeanQuality=(mean(ReviewStatus)))
QualbyPath <- QualbyPath %>% filter (QualbyPath$ClinicalSignificance != "not provided")
QualbyPath <- QualbyPath[complete.cases(QualbyPath),]
barplot(QualbyPath$MeanQuality, names.arg = QualbyPath$ClinicalSignificance, 
        xlab = "Clinical Significance", ylab = "Mean Highest Quality of Evidence",
)

  #Number of evaluations based on initial pathogenicity status (research bias)----
InitialEval <- GeneBankfilt %>% group_by(AlleleID) %>%
  filter(LastEvaluated == min(LastEvaluated)) %>%
  filter(NumberSubmitters == min(NumberSubmitters))
InitialEval <- InitialEval %>% select(AlleleID, ClinicalSignificance)
InitialEval <- distinct(InitialEval)
InitialEval_tbl <- data.table(table(InitialEval$AlleleID))
InitialEval_tbl <- InitialEval_tbl %>% filter(N == 1) %>% select(V1) %>% 
  rename(AlleleID = V1)
InitialEval <- merge(InitialEval, InitialEval_tbl, by = "AlleleID") %>%
  rename(InitialClinSig = ClinicalSignificance)
InitialEval$InitialClinSig <- 
  ifelse(InitialEval$InitialClinSig == "Pathogenic/Likely pathogenic", "P/LP",
         ifelse(InitialEval$InitialClinSig == "Likely pathogenic", "P/LP", 
                ifelse(InitialEval$InitialClinSig == "Pathogenic", "P/LP", 
                       ifelse(InitialEval$InitialClinSig == "Uncertain significance", "C/VUS",
                              ifelse(InitialEval$InitialClinSig == "Conflicting interpretations of pathogenicity", "C/VUS", "B/LB")))))
HighestReeval <- merge(GeneBankfilt, InitialEval, by = "AlleleID") %>%
  group_by(AlleleID) %>%
  filter(NumberSubmitters == max(NumberSubmitters)) %>%
  filter(LastEvaluated == max(LastEvaluated)) %>%
  select(AlleleID, NumberSubmitters, InitialClinSig)
HighestReeval <- distinct(HighestReeval) 
HighestReeval$NumberSubmitters <- as.numeric(HighestReeval$NumberSubmitters)
HighestReeval_tbl <- HighestReeval %>% group_by(InitialClinSig)%>%
  summarise(MeanNumSub=(mean(NumberSubmitters)))
HighestReeval_tbl2 <- HighestReeval %>% group_by(InitialClinSig)%>% 
  summarise(SE = (sqrt(var(NumberSubmitters)/length(NumberSubmitters))))
HighestReeval_tbl2 <- HighestReeval_tbl2 %>% select(SE)
HighestReeval_tbl <- cbind(HighestReeval_tbl, HighestReeval_tbl2)

ggplot(HighestReeval_tbl, aes(x = InitialClinSig, y = MeanNumSub))+
  geom_bar(stat = "identity", color = "black", size = 1.5,
           position = "dodge", fill = "white")+
  geom_errorbar(aes(ymin = (MeanNumSub - SE), ymax = (MeanNumSub + SE)), 
                position = position_dodge(0.9), width = 0.5, size = 1.0)+
  ylab("Mean Number of Submitters")+
  xlab("Initial Pathogenicity Status")+
  ylim(0, 2.5)+
  theme(axis.text = element_text(size = 20, family = "Arial", color = "black", face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 24, family = "Arial", face = "bold", color = "black"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "none")

#If ClinVar
#HighestReeval_tbl_full <- HighestReeval_tbl
#HighestReeval_tbl_full$SetID <- "Aa"

#If full Chnl
#HighestReeval_tbl$SetID <- "A"
#HighestReeval_tbl <- rbind(HighestReeval_tbl, HighestReeval_tbl_full)


  #Likelihood of Change by Highest Review Status at that Time----
#Mean Quality of Evidence of Variants that Change Pathogenicity

#Filter dataset for this analysis
GeneBankfilt_QSC <- GeneBankfilt %>% select(AlleleID, LastEvaluated,
                                            ClinicalSignificance, ReviewStatusHighest)
GeneBankfilt_QSC <- GeneBankfilt_QSC[complete.cases(GeneBankfilt_QSC),]
GeneBankfilt_QSC <- data.table(distinct(GeneBankfilt_QSC))

#Denominator of odds
GeneBankfilt_QSC <- GeneBankfilt_QSC %>% group_by(AlleleID, LastEvaluated)
GeneBankfilt_QSC$group_id <- GeneBankfilt_QSC %>% group_by(AlleleID, LastEvaluated) %>%
  group_indices(AlleleID, LastEvaluated)
tool1 <- data.table(table(GeneBankfilt_QSC$group_id))
names(tool1)[1] <- "group_id"
tool1 <- tool1 %>% filter(N == 1) %>% select(group_id)
GeneBankfilt_QSC <- merge(GeneBankfilt_QSC, tool1, by = "group_id") %>% select(-group_id)

GeneBankfilt_QSC <- group_by(GeneBankfilt_QSC, AlleleID)
GeneBankfilt_last <- filter(GeneBankfilt_QSC, LastEvaluated == max(LastEvaluated))

GeneBankfilt_nolast <- setdiff(GeneBankfilt_QSC, GeneBankfilt_last)

#Numerator of Odds
#First create a data frame that only contains Variants that changed clinical significance
#First, create a new data frame that removes the LastEvaluated variable and then
#removes repeats
GeneBankfilt2 <- GeneBankfilt

GeneBankfilt2$Bucket_Indicator <- 
  ifelse(GeneBankfilt2$ClinicalSignificance == "Pathogenic/Likely pathogenic", "2",
         ifelse(GeneBankfilt2$ClinicalSignificance == "Likely pathogenic", "2", 
                ifelse(GeneBankfilt2$ClinicalSignificance == "Pathogenic", "2", 
                       ifelse(GeneBankfilt2$ClinicalSignificance == "Uncertain significance", "1",
                              ifelse(GeneBankfilt2$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "1", "0")))))

GeneBankfiltnodate2 <- GeneBankfilt2 %>% select(AlleleID, GeneSymbol, 
                                                Bucket_Indicator)

GeneBankfiltnodate2 <- distinct(GeneBankfiltnodate2)

sigchangefreq2 <- data.table(table (GeneBankfiltnodate2$AlleleID))

sigchange2 <- sigchangefreq2 %>%
  filter (N > 1)
names(sigchange2) [1] <- "AlleleID"
sigchange2 <- sigchange2 %>%
  mutate(AlleleID = as.numeric(AlleleID))
#Third, merge the table containing only SNPs that changed clinical significance
#with the original data frame, which includes LastEvaluated, in order to create
#a new data frame with only the SNPs that changed AND all of the pertinent information
#about them
GeneBank.sigchange2 <- merge(x = GeneBankfilt2, y = sigchange2, by = "AlleleID", all.x = TRUE)
GeneBank.sigchange2 <- GeneBank.sigchange2 [complete.cases(GeneBank.sigchange2),]

GeneBank.sigchange2 <- GeneBank.sigchange2 %>% group_by(AlleleID, LastEvaluated)
GeneBank.sigchange2$group_id <- GeneBank.sigchange2 %>% group_by(AlleleID, LastEvaluated) %>%
  group_indices(AlleleID, LastEvaluated)
tool1 <- data.table(table(GeneBank.sigchange2$group_id))
names(tool1)[1] <- "group_id"
tool1 <- tool1 %>% filter(N == 1) %>% select(group_id)
GeneBank.sigchange2 <- merge(GeneBank.sigchange2, tool1, by = "group_id") %>% select(-group_id)

GeneBank.sigchange2 <- GeneBank.sigchange2[
  with(GeneBank.sigchange2, order(AlleleID, LastEvaluated)),
]

GeneBank.sigchange2 <- GeneBank.sigchange2 %>% select(AlleleID, LastEvaluated, 
                                                      Bucket_Indicator, ReviewStatusHighest)

GeneBank.sigchange2$Bucket_Indicator <- as.numeric(GeneBank.sigchange2$Bucket_Indicator)
Storage1 <- data.table(numeric(length(GeneBank.sigchange2$Bucket_Indicator)))
for(i in 2:length(GeneBank.sigchange2$Bucket_Indicator)){
  if(GeneBank.sigchange2$Bucket_Indicator[i] != GeneBank.sigchange2$Bucket_Indicator[i-1]){
    Storage1 [i-1] <- 1
  }else{
    Storage1 [i-1] <- 0
  }
}

names(Storage1) [1] <- "ClinSig_Change_Indicator"
Storage1$ClinSig_Change_Indicator <- as.numeric(Storage1$ClinSig_Change_Indicator)
GeneBank.sigchange2 <- cbind(GeneBank.sigchange2, Storage1)

GeneBank.sigchange2$AlleleID <- as.numeric(GeneBank.sigchange2$AlleleID)
Storage2 <- data.table(numeric(length(GeneBank.sigchange2$AlleleID)))
for(i in 2:length(GeneBank.sigchange2$AlleleID)){
  if(GeneBank.sigchange2$AlleleID[i] == GeneBank.sigchange2$AlleleID[i-1]){
    Storage2 [i-1] <- 1
  }else{
    Storage2 [i-1] <- 0
  }
}

names(Storage2) [1] <- "Allele_Change_Indicator"
#Storage2$Allele_Change_Indicator <- as.numeric(Storage1$Allele_Change_Indicator)
GeneBank.sigchange2 <- cbind(GeneBank.sigchange2, Storage2)

GeneBankfilt_prechange <- GeneBank.sigchange2 %>%
  filter(ClinSig_Change_Indicator == 1 & Allele_Change_Indicator == 1)

GeneBankfilt_prechange$ReviewStatusHighest <- as.numeric(
  GeneBankfilt_prechange$ReviewStatusHighest)

GeneBankfilt_prechange_tbl <- data.table(table(
  GeneBankfilt_prechange$ReviewStatusHighest
))

GeneBankfilt_nolast_tbl <- data.table(table(GeneBankfilt_nolast$ReviewStatusHighest))

GeneBank_changebyQual <- data.table(
  Zero = ((GeneBankfilt_prechange_tbl[1,2])/
            (GeneBankfilt_nolast_tbl[1,2])),
  One = ((GeneBankfilt_prechange_tbl[2,2])/
           (GeneBankfilt_nolast_tbl[2,2])),
  Two = ((GeneBankfilt_prechange_tbl[3,2])/
           (GeneBankfilt_nolast_tbl[3,2])),
  Three = 0
  #((GeneBankfilt_prechange_tbl[4,2])/(GeneBankfilt_nolast_tbl[4,2]))
  #Four = 0, (0/(GeneBankfilt_nolast_tbl[5,2]))
)
GeneBank_changebyQual<- data.table(t(GeneBank_changebyQual))
GeneBank_changebyQual<- GeneBank_changebyQual[complete.cases(GeneBank_changebyQual),]
x <- data.table(HighestQual = c("0", "1", "2", "3"))
GeneBank_changebyQual <- cbind(GeneBank_changebyQual, x) %>% 
  rename(SigChangeOdds = V1)
ggplot(GeneBank_changebyQual, aes(x = HighestQual, y = SigChangeOdds))+
  geom_bar(stat = "identity", color = "black", size = 1.5,
           position = "dodge", fill = "white")+
  ylab("Significant Change Odds")+
  xlab("Highest Quality of Evidence (Stars)")+
  ylim(0, 0.17)+
  theme(axis.text = element_text(size = 20, family = "Arial", color = "black", face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 24, family = "Arial", face = "bold", color = "black"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "none")

#If All ClinVar
#GeneBank_changebyQual_All <- GeneBank_changebyQual
#GeneBank_changebyQual_All$SetID <- "All"

#If Chnl
#GeneBank_changebyQual$SetID <- "AA"
#GeneBank_changebyQual<-rbind(GeneBank_changebyQual, GeneBank_changebyQual_All)

  #Quality of Evidence Change Over Time----
QualOverTime <- GeneBankfilt %>%
  group_by(Year) %>%
  summarise(MeanQuality=(mean(ReviewStatusHighest)))
mean(GeneBankfilt$ReviewStatus)
QualOverTime <- QualOverTime %>% filter(Year > 2010)
barplot(QualOverTime$MeanQuality, names.arg = QualOverTime$Year, 
        main = "Mean Highest Review Status Over Time")

QualOverTime1 <- GeneBankfilt %>%
  group_by(Year) %>%
  summarise(MeanQuality=(mean(ReviewStatus)))
QualOverTime1 <- QualOverTime1 %>% filter(Year > 2010)
barplot(QualOverTime1$MeanQuality, names.arg = QualOverTime1$Year, 
        main = "Mean Review Status Over Time")

  #Submission Type Leading to Change in Evidence----
#Create a data set with only clinically significant change variants
GeneBank_sigind2 <- GeneBankfilt %>% select(AlleleID, ClinicalSignificance)
GeneBank_sigind2$ClinicalSignificance <- 
  ifelse(GeneBank_sigind2$ClinicalSignificance == "Pathogenic/Likely pathogenic", "2",
         ifelse(GeneBank_sigind2$ClinicalSignificance == "Likely pathogenic", "2", 
                ifelse(GeneBank_sigind2$ClinicalSignificance == "Pathogenic", "2", 
                       ifelse(GeneBank_sigind2$ClinicalSignificance == "Uncertain significance", "1",
                              ifelse(GeneBank_sigind2$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "1", "0")))))
GeneBank_sigind2 <- distinct(GeneBank_sigind2)
GeneBank_sigindfreq2 <- data.table(table(GeneBank_sigind2$AlleleID))
GeneBank_sigindfreq2 <- GeneBank_sigindfreq2 %>% filter(N > 1)
names(GeneBank_sigindfreq2) [1] <- "AlleleID"
GeneBank_sigindfreq2 <- GeneBank_sigindfreq2 %>% mutate(AlleleID = as.numeric(AlleleID))
GeneBank_sigchange2 <- merge (x = GeneBankfilt, y = GeneBank_sigindfreq2, by = "AlleleID")
GeneBank_sigchange2 <- GeneBank_sigchange2 %>% select(AlleleID, GeneSymbol, 
                                                      ClinicalSignificance, LastEvaluated, 
                                                      Year, CollectionMethod)
GeneBank_sigchange2$ID2 <- seq.int(nrow(GeneBank_sigchange2))
GeneBank_sigind_changeind2 <- GeneBank_sigchange2 %>% 
  select(AlleleID, ClinicalSignificance, LastEvaluated, Year, CollectionMethod)
GeneBank_sigind_changeind2$Bucket_Indicator <- 
  ifelse(GeneBank_sigchange2$ClinicalSignificance == "Pathogenic/Likely pathogenic", "2",
         ifelse(GeneBank_sigchange2$ClinicalSignificance == "Likely pathogenic", "2", 
                ifelse(GeneBank_sigchange2$ClinicalSignificance == "Pathogenic", "2", 
                       ifelse(GeneBank_sigchange2$ClinicalSignificance == "Uncertain significance", "1",
                              ifelse(GeneBank_sigchange2$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "1", "0")))))
GeneBank_sigind_changeind2$ID2 <- seq.int(nrow(GeneBank_sigind_changeind2))
GeneBank_sigchange2$ID2 <- seq.int(nrow(GeneBank_sigchange2))
GeneBank_sigchange2 <- data.table(GeneBank_sigchange2[with(GeneBank_sigchange2, 
                                                           order(AlleleID, LastEvaluated)),])
GeneBank_sigind_changeind2 <- GeneBank_sigind_changeind2 %>% select("ID2", "Bucket_Indicator")
GeneBank_sigchange_changeind2 <- merge (x=GeneBank_sigchange2, y= GeneBank_sigind_changeind2, by = "ID2")

GeneBank_sigchange_changeind2$Bucket_Indicator <- as.numeric(GeneBank_sigind_changeind2$Bucket_Indicator)
Storage1 <- data.table(numeric(length(GeneBank_sigind_changeind2$Bucket_Indicator)))
for(i in 2:length(GeneBank_sigind_changeind2$Bucket_Indicator)){
  if(GeneBank_sigind_changeind2$Bucket_Indicator[i] != GeneBank_sigind_changeind2$Bucket_Indicator[i-1]){
    Storage1 [i] <- 1
  }else{
    Storage1 [i] <- 0
  }
}
Storage1$ID2 <- seq.int(nrow(Storage1))
names(Storage1) [1] <- "ClinSig_Change_Indicator"
Storage1$ClinSig_Change_Indicator <- as.numeric(Storage1$ClinSig_Change_Indicator)
GeneBank_sigchange_changeind2 <- merge(x=GeneBank_sigchange_changeind2, y=Storage1, by = "ID2")

GeneBank_sigind_alleleind2 <- GeneBank_sigchange2 %>% select(AlleleID, ClinicalSignificance, LastEvaluated)
GeneBank_sigind_alleleind2$ID2 <- seq.int(nrow(GeneBank_sigind_alleleind2))
GeneBank_sigind_alleleind2 <- GeneBank_sigind_alleleind2 %>% select("ID2", "AlleleID")

GeneBank_sigind_alleleind2$AlleleID <- as.numeric(GeneBank_sigind_alleleind2$AlleleID)
Storage2 <- data.table(numeric(length(GeneBank_sigind_alleleind2$AlleleID)))
for(i in 2:length(GeneBank_sigind_alleleind2$AlleleID)){
  if(GeneBank_sigind_alleleind2$AlleleID[i] == GeneBank_sigind_alleleind2$AlleleID[i-1]){
    Storage2 [i] <- 1
  }else{
    Storage2 [i] <- 0
  }
}

Storage2$ID2 <- seq.int(nrow(Storage2))
names(Storage2) [1] <- "Allele_Change_Indicator"
Storage2$Allele_Change_Indicator <- as.numeric(Storage2$Allele_Change_Indicator)
GeneBank_sigchange_changeind2 <- merge(x=GeneBank_sigchange_changeind2, y=Storage2, by = "ID2")

GeneBank_sigchange_changeind2 <- GeneBank_sigchange_changeind2 %>%
  filter(ClinSig_Change_Indicator == 1 & Allele_Change_Indicator == 1)

GeneBank_sigchange_changeind2_tbl <- data.table(table(GeneBank_sigchange_changeind2$CollectionMethod))
GeneBank_sigchange_changeind2_tbl$Proportion <- GeneBank_sigchange_changeind2_tbl$N / 
  sum(GeneBank_sigchange_changeind2_tbl$N) 
GeneBank_sigchange_changeind2_tbl <- GeneBank_sigchange_changeind2_tbl %>%
  filter(Proportion > 0.02)
View(GeneBank_sigchange_changeind2_tbl)

GeneBankfilt_methodtbl <- data.table(table(GeneBankfilt$CollectionMethod))
GeneBankfilt_methodtbl$Proportion <- GeneBankfilt_methodtbl$N / 
  sum(GeneBankfilt_methodtbl$N)
GeneBankfilt_methodtbl <- GeneBankfilt_methodtbl %>%
  filter(Proportion > 0.02)
View(GeneBankfilt_methodtbl)

#Experimental
GeneBank_sigchange_changeind2_LPP <- GeneBank_sigchange_changeind2 %>% 
  filter(Bucket_Indicator == 2)
GeneBank_sigchange_changeind2_LPP_tbl <- data.table(table(GeneBank_sigchange_changeind2_LPP$CollectionMethod))
GeneBank_sigchange_changeind2_LPP_tbl$Proportion <- GeneBank_sigchange_changeind2_LPP_tbl$N / 
  sum(GeneBank_sigchange_changeind2_LPP_tbl$N) 
GeneBank_sigchange_changeind2_LPP_tbl <- GeneBank_sigchange_changeind2_LPP_tbl %>%
  filter(Proportion > 0.02)

GeneBank_sigchange2_tool <- GeneBank_sigchange2 %>% select(AlleleID)
GeneBank_sigchange_firsteval <- merge(GeneBankfilt, GeneBank_sigchange2_tool,
                                      by = "AlleleID")
GeneBank_sigchange_firsteval <- GeneBank_sigchange_firsteval %>% 
  group_by(AlleleID) %>%
  filter(LastEvaluated == min(LastEvaluated))
GeneBank_sigchange_firsteval$ClinicalSignificance <- 
  ifelse(GeneBank_sigchange_firsteval$ClinicalSignificance == "Pathogenic/Likely pathogenic", "2",
         ifelse(GeneBank_sigchange_firsteval$ClinicalSignificance == "Likely pathogenic", "2", 
                ifelse(GeneBank_sigchange_firsteval$ClinicalSignificance == "Pathogenic", "2", 
                       ifelse(GeneBank_sigchange_firsteval$ClinicalSignificance == "Uncertain significance", "1",
                              ifelse(GeneBank_sigchange_firsteval$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "1", "0")))))
GeneBank_sigchange_firsteval <- GeneBank_sigchange_firsteval %>% 
  select(AlleleID, ClinicalSignificance, CollectionMethod)
GeneBank_sigchange_firsteval <- distinct(GeneBank_sigchange_firsteval)
GeneBank_sigchange_firsteval_tbl <- data.table(table(GeneBank_sigchange_firsteval$AlleleID))
GeneBank_sigchange_firsteval_tbl <- GeneBank_sigchange_firsteval_tbl %>% filter(N == 1)
GeneBank_sigchange_firsteval_tbl <- GeneBank_sigchange_firsteval_tbl %>%
  rename(AlleleID = V1)
GeneBank_sigchange_firsteval <- merge(GeneBank_sigchange_firsteval, 
                                      GeneBank_sigchange_firsteval_tbl, by = "AlleleID")
GeneBank_sigchange_firsteval_lit <- GeneBank_sigchange_firsteval %>%
  filter(CollectionMethod == c("literature only"))
GeneBank_sigchange_firsteval_lit_tbl <- data.table(table(GeneBank_sigchange_firsteval_lit$ClinicalSignificance))
View(GeneBank_sigchange_firsteval_lit_tbl)

LitChangeFig <- data.table(
  Labels = c("Lit Only Proportion", "Odds if Lit Only", "Odds if Non-Lit",
             "Lit Only Proportion", "Odds if Lit Only", "Odds if Non-Lit"),
  P = c(0.21, 0.1, 0.02, 0.18, 0.44, 0.08),
  SetID = c("Chnl", "Chnl", "Chnl", "ClinVar", "ClinVar", "ClinVar")
)

ggplot(LitChangeFig, aes(x = Labels, y = P, fill = SetID))+
  geom_bar(stat = "identity", color = "black", size = 1.5,
           position = "dodge")+
  ylab("Proportion")+
  ylim(0, 0.5)+
  scale_fill_manual(values = c("white", "red3"))+
  theme(axis.text = element_text(size = 20, family = "Arial", color = "black", face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 24, family = "Arial", face = "bold", color = "black"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "none")

  #Submission Type upon Initial Evaluation----
GeneBank_first <- GeneBankfilt %>% group_by(AlleleID) %>% 
  filter(LastEvaluated == min(LastEvaluated))
GeneBank_first$ClinicalSignificance <- 
  ifelse(GeneBank_first$ClinicalSignificance == "Pathogenic/Likely pathogenic", "2",
         ifelse(GeneBank_first$ClinicalSignificance == "Likely pathogenic", "2", 
                ifelse(GeneBank_first$ClinicalSignificance == "Pathogenic", "2", 
                       ifelse(GeneBank_first$ClinicalSignificance == "Uncertain significance", "1",
                              ifelse(GeneBank_first$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "1", "0")))))

GeneBank_first_tbl <- data.table(table(GeneBank_first$ClinicalSignificance, 
                                       GeneBank_first$CollectionMethod))
GeneBank_first_tbl2 <- GeneBank_first_tbl %>% filter(V1 == 2)
GeneBank_first_tbl2$Proportion <- GeneBank_first_tbl2$N/sum(GeneBank_first_tbl2$N)
GeneBank_first_tbl1 <- GeneBank_first_tbl %>% filter(V1 == 1)
GeneBank_first_tbl1$Proportion <- GeneBank_first_tbl1$N/sum(GeneBank_first_tbl1$N)
GeneBank_first_tbl0 <- GeneBank_first_tbl %>% filter(V1 == 0)
GeneBank_first_tbl0$Proportion <- GeneBank_first_tbl0$N/sum(GeneBank_first_tbl0$N)

GeneBank_first_tbl <- rbind(GeneBank_first_tbl2, GeneBank_first_tbl1,
                            GeneBank_first_tbl0)

#What happened to the variants initially labeled pathogenic by 
#literature alone
GeneBankfilt_litpath <- GeneBank_first 
GeneBankfilt_litpath <- GeneBankfilt_litpath %>%
  filter(ClinicalSignificance == 2) #%>%
#filter(CollectionMethod == c("literature only")) 
GeneBank_sigchange_tool <- GeneBank_sigchange %>% select(AlleleID)
GeneBank_sigchange_tool <- distinct(GeneBank_sigchange_tool)
GeneBankfilt_litpath_sigchange <- merge(GeneBankfilt_litpath, GeneBank_sigchange_tool,
                                        by = "AlleleID")

n_distinct(GeneBankfilt_litpath_sigchange$AlleleID)
n_distinct(GeneBankfilt_litpath$AlleleID)

#Who submitted those variants initially pathogenic by literature alone which
#then were downgraded?
GeneBank_lpsc_submitters <- merge(GeneBank_sigchange_tool, GeneBank, by = "AlleleID") %>%
  select(AlleleID, LastEvaluated, Submitter)

GeneBank_lpsc_submitters <- GeneBank_lpsc_submitters %>%
  group_by(AlleleID) %>%
  filter(LastEvaluated == min(LastEvaluated))

GeneBank_lpsc_submitters <- GeneBank_lpsc_submitters[complete.cases(GeneBank_lpsc_submitters),]
GeneBank_lpsc_submitters <- distinct(GeneBank_lpsc_submitters)
GeneBank_lpsc_submitters_tbl <- data.table(table(GeneBank_lpsc_submitters$Submitter))
View(GeneBank_lpsc_submitters_tbl)



#Set of variants that underwent a clinically meaningful change with initial
#and final evaluations in the same row
GeneBank_sigchange_tool <- GeneBank_sigchange %>% select(AlleleID)
GeneBank_sigchange_tool <- distinct(GeneBank_sigchange_tool)
GeneBank_sigchange_ba <- merge(GeneBank_first, GeneBank_sigchange_tool,
                               by = "AlleleID") %>%
  select(AlleleID, GeneSymbol, ClinicalSignificance, LastEvaluated, CollectionMethod)
GeneBank_sigchange_ba <- distinct(GeneBank_sigchange_ba)
GeneBank_sigchange_ba_tool <- data.table(table(GeneBank_sigchange_ba$AlleleID)) %>%
  filter(N == 1)
GeneBank_sigchange_ba_tool <- GeneBank_sigchange_ba_tool %>%
  rename(AlleleID = V1)
GeneBank_sigchange_ba_tool$AlleleID <- as.numeric(GeneBank_sigchange_ba_tool$AlleleID)
GeneBank_sigchange_ba <- merge(GeneBank_sigchange_ba_tool, GeneBank_sigchange_ba,
                               by = "AlleleID")

  #What countered the initial literature-based evaluation?----
GeneBankfilt_litpath_sigchange.2 <- GeneBankfilt_litpath_sigchange %>%
  select(AlleleID)
GeneBank_sigchange_litonfirsteval <- merge(GeneBankfilt_litpath_sigchange.2,
                                           GeneBank_sigchange_changeind, by = "AlleleID")
GeneBank_sigchange_litonfirsteval <- GeneBank_sigchange_litonfirsteval %>%
  group_by(AlleleID) %>%
  filter(LastEvaluated == min(LastEvaluated)) %>%
  select(AlleleID, GeneSymbol, ClinicalSignificance, LastEvaluated)
GeneBank_sigchange_litonfirsteval <- distinct(GeneBank_sigchange_litonfirsteval)
GeneBank_sigchange_litonfirsteval <- left_join(
  GeneBank_sigchange_litonfirsteval, GeneBankfilt, by = c("AlleleID", "GeneSymbol",
                                                          "ClinicalSignificance",
                                                          "LastEvaluated")) %>%
  select(AlleleID, GeneSymbol, LastEvaluated, CollectionMethod)
GeneBank_sigchange_litonfirsteval <- distinct(GeneBank_sigchange_litonfirsteval)



GeneBank_sigchange_litonfirsteval_tbl <- data.table(table(
  GeneBank_sigchange_litonfirsteval$CollectionMethod))
View(GeneBank_sigchange_litonfirsteval_tbl)

  #Sub-analysis for high quality submissions----
#Initial Quality of Evidence
#Must first run 2d

firsteval <- GeneBankdt_firsteval %>% select(AlleleID, GeneSymbol, LastEvaluated)
GeneBankfilt_firsteval <- merge(GeneBankfilt, firsteval, by = c("AlleleID", "GeneSymbol", "LastEvaluated"))
GeneBankfilt_firsteval <- GeneBankfilt_firsteval %>% select(AlleleID, GeneSymbol, LastEvaluated, ReviewStatusHighest)
GeneBankfilt_firsteval <- data.table(distinct(GeneBankfilt_firsteval))

#Keep only variants with an initial quality of evidence of 2+ stars
GeneBankfilt_hifirsteval <- GeneBankfilt_firsteval %>% filter(ReviewStatusHighest > 1)

#Figures----

#1: Summary of Data----

  #1a: Table output for the given gene----
GeneBank_Output <- data.frame("Genes" = c("Gene"), 
                              "Number_of_SNPs" = n_distinct(GeneBankdt$AlleleID), 
                              "SNPs_Reevaluated" = n_distinct(GeneBank.reeval$AlleleID),
                              "Avg_Reeval" = mean(eval_freq$N),
                              "SNPs_that_Changed_Clinical_Significance" = n_distinct(GeneBank.changed$AlleleID),
                              "SNPs_with_a_Clinically_Meaningful_Change" = n_distinct(GeneBank_sigchange$AlleleID),
                              "Proportion_Meaningful" = 
                                n_distinct(GeneBank_sigchange$AlleleID)/n_distinct(GeneBankdt$AlleleID))

View(GeneBank_Output)
  #1b: Bar graph of Reevaluations by AlleleID----
names(eval_freq) [1] <- "AlleleID"
eval_freq <- eval_freq %>%
  mutate(AlleleID = as.numeric(AlleleID))
reeval.2 <- reeval 
reeval.2$N <- reeval.2$N - 1
ggplot(reeval.2, aes(x = N))+
  geom_bar(width = 0.8, fill = "white", 
           color = "black", size = 1.5)+
  xlab("Number of Times Reevaluated")+
  scale_x_continuous(breaks = c(0, 5, 10))+
  ylab("Number of Variants")+
  theme(axis.text = element_text(size = 20, family = "Arial", color = "black", face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", face = "bold", color = "black"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank())
AvgReeval <- mean(eval_freq$N)
1.96*sd(eval_freq$N)/sqrt(nrow(eval_freq))

  #1c: Summary of Genes by Year for Total Number of Alleles----
GeneBankdt_bygene_first_TTN <- GeneBankdt_bygene_first %>% filter(Gene == "TTN")
GeneBankdt_bygene_first_MYH7 <- GeneBankdt_bygene_first %>% filter(Gene == "MYH7")
GeneBankdt_bygene_first_MYBPC3 <- GeneBankdt_bygene_first %>% filter(Gene == "MYBPC3")
GeneBankdt_bygene_first_MYL2 <- GeneBankdt_bygene_first %>% filter(Gene == "MYL2")
GeneBankdt_bygene_first_MYL3 <- GeneBankdt_bygene_first %>% filter(Gene == "MYL3")
GeneBankdt_bygene_first_ACTC1 <- GeneBankdt_bygene_first %>% filter(Gene == "ACTC1")
GeneBankdt_bygene_first_TPM1 <- GeneBankdt_bygene_first %>% filter(Gene == "TPM1")
GeneBankdt_bygene_first_TNNT2 <- GeneBankdt_bygene_first %>% filter(Gene == "TNNT2")
GeneBankdt_bygene_first_TNNI3 <- GeneBankdt_bygene_first %>% filter(Gene == "TNNI3")
GeneBankdt_bygene_first_TNNC1 <- GeneBankdt_bygene_first %>% filter(Gene == "TNNC1")
GeneBankdt_bygene_first_PKP2 <- GeneBankdt_bygene_first %>% filter(Gene == "PKP2")
GeneBankdt_bygene_first_DSP <- GeneBankdt_bygene_first %>% filter(Gene == "DSP")
GeneBankdt_bygene_first_DSG2 <- GeneBankdt_bygene_first %>% filter(Gene == "DSG2")
GeneBankdt_bygene_first_DSC2 <- GeneBankdt_bygene_first %>% filter(Gene == "DSC2")
GeneBankdt_bygene_first_JUP <- GeneBankdt_bygene_first %>% filter(Gene == "JUP")
GeneBankdt_bygene_first_TMEM43 <- GeneBankdt_bygene_first %>% filter(Gene == "TMEM43")
GeneBankdt_bygene_first_TTN$NumSum <- cumsum(GeneBankdt_bygene_first_TTN$Number_of_Variants)
GeneBankdt_bygene_first_MYH7$NumSum <- cumsum(GeneBankdt_bygene_first_MYH7$Number_of_Variants)
GeneBankdt_bygene_first_MYBPC3$NumSum <- cumsum(GeneBankdt_bygene_first_MYBPC3$Number_of_Variants)
GeneBankdt_bygene_first_MYL2$NumSum <- cumsum(GeneBankdt_bygene_first_MYL2$Number_of_Variants)
GeneBankdt_bygene_first_MYL3$NumSum <- cumsum(GeneBankdt_bygene_first_MYL3$Number_of_Variants)
GeneBankdt_bygene_first_ACTC1$NumSum <- cumsum(GeneBankdt_bygene_first_ACTC1$Number_of_Variants)
GeneBankdt_bygene_first_TPM1$NumSum <- cumsum(GeneBankdt_bygene_first_TPM1$Number_of_Variants)
GeneBankdt_bygene_first_TNNT2$NumSum <- cumsum(GeneBankdt_bygene_first_TNNT2$Number_of_Variants)
GeneBankdt_bygene_first_TNNI3$NumSum <- cumsum(GeneBankdt_bygene_first_TNNI3$Number_of_Variants)
GeneBankdt_bygene_first_TNNC1$NumSum <- cumsum(GeneBankdt_bygene_first_TNNC1$Number_of_Variants)
GeneBankdt_bygene_first_PKP2$NumSum <- cumsum(GeneBankdt_bygene_first_PKP2$Number_of_Variants)
GeneBankdt_bygene_first_DSP$NumSum <- cumsum(GeneBankdt_bygene_first_DSP$Number_of_Variants)
GeneBankdt_bygene_first_DSG2$NumSum <- cumsum(GeneBankdt_bygene_first_DSG2$Number_of_Variants)
GeneBankdt_bygene_first_DSC2$NumSum <- cumsum(GeneBankdt_bygene_first_DSC2$Number_of_Variants)
GeneBankdt_bygene_first_JUP$NumSum <- cumsum(GeneBankdt_bygene_first_JUP$Number_of_Variants)
GeneBankdt_bygene_first_TMEM43$NumSum <- cumsum(GeneBankdt_bygene_first_TMEM43$Number_of_Variants)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_TTN, GeneBankdt_bygene_first_MYH7)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_MYBPC3)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_MYL2)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_MYL3)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_ACTC1)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_TPM1)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_TNNT2)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_TNNI3)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_TNNC1)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_PKP2)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_DSP)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_DSG2)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_DSC2)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_JUP)
GeneBankdt_bygene_first_all <- rbind(GeneBankdt_bygene_first_all, GeneBankdt_bygene_first_TMEM43)

GeneBankdt_bygene_first_all <- GeneBankdt_bygene_first_all %>%
  filter(Year>2010)
GeneBankdt_bygene_first_all.order <- GeneBankdt_bygene_first_all %>%
  select("Gene")
#GeneBankdt_bygene_first_all.order2 <- GeneBankdt_bygene_first_all.order
names(GeneBankdt_bygene_first_all.order)[1] <- "Gene_Order"
#GeneBankdt_bygene_first_all.order <- cbind(GeneBankdt_bygene_first_all.order, 
# GeneBankdt_bygene_first_all.order2)
GeneBankdt_bygene_first_all.order$Gene_Order <-  
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "TTN", "1",
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "TNNI3", "9", 
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "MYBPC3", "3", 
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "MYL2", "4",
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "MYH7", "2", 
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "MYL3", "5",
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "ACTC1", "6",        
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "TPM1", "7",   
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "TNNT2", "8",
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "TNNC1", "10",
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "PKP2", "11",
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "DSP", "12",
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "DSG2", "13",
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "DSC2", "14",
  ifelse(GeneBankdt_bygene_first_all.order$Gene_Order == "JUP", "15",
         "16"
                                                          )))))))))))))))
GeneBankdt_bygene_first_all <- cbind(GeneBankdt_bygene_first_all,
                                     GeneBankdt_bygene_first_all.order)

b <- ggplot(GeneBankdt_bygene_first_all, 
       aes(fill = factor(Gene, levels = c("TTN", "TNNI3", "MYBPC3", "MYL2", 
                                          "MYH7", "MYL3", "ACTC1", "TPM1", 
                                          "TNNT2", "TNNC1", "PKP2", "DSP", "DSG2", 
                                          "DSC2", "JUP", "TMEM43")), 
           x = Year, y = NumSum))+
  geom_bar(stat = "identity",  color = "black")+
  scale_fill_manual(values=as.vector(stepped2(16)),
                    name = "Gene", 
                    labels = c("TTN", "TNNI3", "MYBPC3", "KCNH2", "MYH7", "MYL3", 
                               "ACTC1", "TPM1", "TNNT2", "TNNC1", "PKP2","DSP",
                                "DSG2","DSC2","JUP", "TMEM43"))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(nrow = 8))+
  theme(axis.text = element_text(size = 26, family = "Arial", color = "black", face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 26, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "right", legend.text = element_text(size = 26, family = "Arial", face = "italic", color = "black"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 26, face = "bold"))
b

  #1d: Summative analysis of Significance Level of all new variants----
FirstTable <- data.table (table (GeneBankdt_firsteval$Significance_Level_Indicator))
FirstTable$V1 <- 
  ifelse(FirstTable$V1 == -3, "B", 
         ifelse(FirstTable$V1 == -2, "B/LB",
                ifelse(FirstTable$V1 == -1, "LB",
                       ifelse(FirstTable$V1 == 0, "C/VUS",
                              ifelse(FirstTable$V1 == 1, "LP",
                                     ifelse(FirstTable$V1 == 2, "P/LP", "P"))))))
c <- ggplot(FirstTable, aes(fill = V1, x = V1, y = N))+
  geom_bar(stat = "identity", color = "black")+
  coord_flip()+
  scale_fill_manual(values = c("dodgerblue4", "dodgerblue3", "white", "dodgerblue2", 
                               "deeppink2", "deeppink4", "deeppink3"), name = "Significance Level", 
                    labels = c( "Likely Benign", 
                                "Bngn/Likely Bngn", "Benign", "Uncertain/Conflicting",
                                "Likely Pathogenic", "Path/Likely path", "Pathogenic"))+
  scale_x_discrete(limits = c("B", "B/LB", "LB", "C/VUS", "LP", "P/LP", "P"))+
  scale_y_continuous()+
  ylab("Number of Variants")+
  xlab("Pathogenicity Assignment")+
  theme(axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        axis.text = element_text(size = 26, family = "Arial", color = "black", face = "bold"),
        text = element_text(size = 26, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "none")

c

GeneBank_sigchange_changeind_filt <- GeneBank_sigchange_changeind %>%
  select("ID", "AlleleID", "GeneSymbol", "Significance_Level_Indicator")

#Other: Histogram of Significant Reevaluations by AlleleID----
GeneBank_sigchange_changeindtbl <- data.table(table(GeneBank_sigchange_changeind$AlleleID))
ggplot(GeneBank_sigchange_changeindtbl, aes(x = N))+
  geom_histogram(binwidth = 1, fill = "gray70", color = "black")+
  xlab("Number of Times Reevaluated")+
  ylab("Number of Variants")+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", face = "bold", color = "black"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.text = element_text(size = 20, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))


#Summary of Genes by Year for Number of New Alleles
ggplot(GeneBankdt_bygene_first, aes(fill = Gene, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_fill(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("black", "darkblue", "blue", "darkgreen", 
                               "orange", "white"), 
                    name = "Significance Certainty", labels = c( "AKAP9", "ANK2", "KCNH2", "KCNQ1", "RYR2", "SCN5A"))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))
ggplot(GeneBankdt_bygene_first, aes(fill = Gene, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_stack(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("black", "darkblue", "blue", "darkgreen", 
                               "orange", "white"), name = "Significance Certainty", 
                    labels = c( "AKAP9", "ANK2", "KCNH2", "KCNQ1", "RYR2", "SCN5A"))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))


#Summary of Genes by Year for Significant Reevaluations
ggplot(GeneBank_bygene, aes(fill = Gene, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_fill(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("black", "gray", "lightgreen", "seagreen", 
                               "darkgreen", "darkblue","blue", "orange3", "yellow3", "white"), 
                    name = "Significance Certainty", labels = c( "CACNA1C", "CALM1", "CALM2",
                                                                 "CALM3", "CASQ9", "KCNH2", "KCNQ1", "RYR2", "SCN5A", "TRDN"))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))
ggplot(GeneBank_bygene, aes(fill = Gene, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_stack(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("black", "gray", "lightgreen", "seagreen", 
                               "darkgreen", "darkblue","blue", "orange3", "yellow3", "white"), 
                    name = "Significance Certainty", labels = c( "CACNA1C", "CALM1", "CALM2",
                                                                 "CALM3", "CASQ9", "KCNH2", "KCNQ1", "RYR2", "SCN5A", "TRDN"))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

#Distribution of Variant Types
GeneBankdt_firsteval.2 <- data.table(table(GeneBankdt_firsteval$Type))
names(GeneBankdt_firsteval.2)[1] <- "Type"
names(GeneBankdt_firsteval.2)[2] <- "Number_of_Variants"
ggplot(GeneBankdt_firsteval.2, aes(fill = Type, x = Type, y = Number_of_Variants))+
  geom_bar(stat = "identity", width = 0.5)+
  theme(legend.position = "bottom")+
  scale_fill_manual(values = c("gray"))+
  ylab("Number of Variants")+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 24, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "none", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

#Summative analysis of Significance Level over All Years
SigLevelYrTable <- data.table (table (GeneBank_sigchange_changeind$Significance_Level))
SigLevelYrTable$V1 <- 
  ifelse(SigLevelYrTable$V1 == -3, "B", 
         ifelse(SigLevelYrTable$V1 == -2, "B/LB",
                ifelse(SigLevelYrTable$V1 == -1, "LB",
                       ifelse(SigLevelYrTable$V1 == 0, "C/VUS",
                              ifelse(SigLevelYrTable$V1 == 1, "LP",
                                     ifelse(SigLevelYrTable$V1 == 2, "P/LP", "P"))))))
ggplot(SigLevelYrTable, aes(fill = V1, x = V1, y = N))+
  geom_bar(stat = "identity", color = "black")+
  coord_flip()+
  scale_fill_manual(values = c("darkolivegreen4", "darkolivegreen3", "white", "darkolivegreen1", 
                               "firebrick1", "firebrick4", "firebrick3"), name = "Significance Level", labels = c( "Likely Benign", 
                                                                                                                   "Bngn/Likely Bngn", "Benign", "Uncertain/Conflicting",
                                                                                                                   "Likely Pathogenic", "Path/Likely path", "Pathogenic"))+
  scale_x_discrete(limits = c("B", "B/LB", "LB", "C/VUS", "LP", "P/LP", "P"))+
  ylab("Number of Variants")+
  xlab("Signficance Level")+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "none", legend.text = element_blank(), 
        legend.title = element_blank())

GeneBank_sigchange_changeind_filt <- GeneBank_sigchange_changeind %>%
  select("ID", "AlleleID", "GeneSymbol", "Significance_Level_Indicator")

#2: Tracking Variant Change Over Time----  

#Tracking Reevaluations first --> last
GeneBank_nofirst.2 <- data.table (GeneBankdt_nofirst)
GeneBank_nofirst.2 <- group_by(GeneBank_nofirst.2, AlleleID)
GeneBank_nofirst_lastre <- filter(GeneBank_nofirst.2,
                                  LastEvaluated == max(LastEvaluated))
GeneBank_nofirst_lastretbl <- data.table(table(GeneBank_nofirst_lastre$AlleleID))
GeneBank_nofirst_lastretbl <- GeneBank_nofirst_lastretbl %>%
  filter(N==1)
names(GeneBank_nofirst_lastretbl) [1] <- "AlleleID"
GeneBank_nofirst_lastre <- merge(x=GeneBank_nofirst_lastre, 
                                 y=GeneBank_nofirst_lastretbl, by = "AlleleID")
GeneBank_nofirst_lastre.2 <- GeneBank_nofirst_lastre
GeneBank_nofirst_lastre <- GeneBank_nofirst_lastre %>%
  select("AlleleID", "Significance_Level_Indicator")
names(GeneBank_nofirst_lastre)[2] <- "Significance_Level_Indicator_Final" 
GeneBank_reeval_lastre_tracker <- merge (x=GeneBankdt_firsteval, 
                                         y= GeneBank_nofirst_lastre, by = "AlleleID")

GeneBank_reeval_lastre_levelyr_tracker0 <-  data.table(GeneBank_reeval_lastre_tracker$Significance_Level_Indicator, 
                                                       GeneBank_reeval_lastre_tracker$Significance_Level_Indicator_Final)
names(GeneBank_reeval_lastre_levelyr_tracker0) [1] <- "Significance_Level"
names(GeneBank_reeval_lastre_levelyr_tracker0) [2] <- "Significance_Level_Final"
GeneBank_reeval_lastre_levelyr_tracker <- data.table(table(GeneBank_reeval_lastre_tracker$Significance_Level_Indicator, 
                                                           GeneBank_reeval_lastre_tracker$Significance_Level_Indicator_Final))
names(GeneBank_reeval_lastre_levelyr_tracker) [1] <- "Significance_Level"
names(GeneBank_reeval_lastre_levelyr_tracker) [2] <- "Significance_Level_Final"
names(GeneBank_reeval_lastre_levelyr_tracker) [3] <- "Number_of_Variants"

GeneBank_reeval_lastre_levelyr_tracker_binned0 <- 
  ifelse(GeneBank_reeval_lastre_levelyr_tracker0$Significance_Level<0, "LB/B",
         ifelse(GeneBank_reeval_lastre_levelyr_tracker0$Significance_Level == 0, "Conflicting/VUS",
                " LP/P"))
GeneBank_reeval_lastre_levelyr_tracker_binned0 <- data.table(GeneBank_reeval_lastre_levelyr_tracker_binned0)
names(GeneBank_reeval_lastre_levelyr_tracker_binned0)[1] <- "Significance_Level"
GeneBank_reeval_lastre_levelyr_tracker_binned0$Significance_Level_Final <- 
  ifelse(GeneBank_reeval_lastre_levelyr_tracker0$Significance_Level_Final<0, "LB/B",
         ifelse(GeneBank_reeval_lastre_levelyr_tracker0$Significance_Level_Final == 0, "Conflicting/VUS",
                " LP/P"))
GeneBank_reeval_lastre_levelyr_tracker_binned <- data.table(table(GeneBank_reeval_lastre_levelyr_tracker_binned0))
names(GeneBank_reeval_lastre_levelyr_tracker_binned) [3] <- "Number_of_Variants"
GeneBank_reeval_lastre_levelyr_tracker_binned.2 <- gather_set_data(GeneBank_reeval_lastre_levelyr_tracker_binned, 1:2)

ggplot(GeneBank_reeval_lastre_levelyr_tracker_binned.2, aes(x, id = id, split = y, 
                                                            value = Number_of_Variants))+
  geom_parallel_sets(aes(fill = Significance_Level), alpha = 0.4, axis.width = 0.1)+
  geom_parallel_sets_axes(axis.width = .1, fill = "white")+
  geom_parallel_sets_labels(color = "black", size = 6, family = "Arial", angle = 90)+
  scale_x_discrete(labels = c("Significance", " "))+
  scale_fill_manual(values = c("firebrick3", "orange1", "darkolivegreen4"))+
  theme(text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        panel.grid.major = element_blank(), axis.title = element_blank(),
        axis.line.y = element_blank(), axis.text.y = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(), 
        legend.text = element_blank(), legend.position = "none",
        legend.title = element_text(size = 20, face = "bold"), axis.ticks.length = unit (0, "pt"))

  #2a: Alluvial without labels----
a <- ggplot(GeneBank_reeval_lastre_levelyr_tracker_binned.2, aes(x, id = id, split = y, 
                                                            value = Number_of_Variants))+
  geom_parallel_sets(aes(fill = Significance_Level), alpha = 0.4, axis.width = 0.1)+
  geom_parallel_sets_axes(axis.width = .1, fill = "white")+
  geom_parallel_sets_labels(color = "black", size = 0, family = "Arial", angle = 90)+
  scale_x_discrete(labels = c(" ", " "))+
  scale_fill_manual(values = c("deeppink3", "mediumpurple1", "dodgerblue3"))+
  theme(text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        panel.grid.major = element_blank(), axis.title = element_blank(),
        axis.line.y = element_blank(), axis.text.y = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(), 
        legend.text = element_blank(), legend.position = "none",
        legend.title = element_text(size = 20, face = "bold"), axis.ticks.length = unit (0, "pt"))

a


  #2b: Alluvial Quantification (percents)----
Alluvial_Breakdown <- data.table(
  P_LP = (GeneBank_reeval_lastre_levelyr_tracker_binned.2[2,3] + 
            GeneBank_reeval_lastre_levelyr_tracker_binned.2 [3,3])/
    (GeneBank_reeval_lastre_levelyr_tracker_binned.2[2,3] + 
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [3,3] +
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [4,3] +
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [6,3] +
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [7,3] +
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [8,3]),
  C_VUS = (GeneBank_reeval_lastre_levelyr_tracker_binned.2[4,3] + 
             GeneBank_reeval_lastre_levelyr_tracker_binned.2 [6,3])/
    (GeneBank_reeval_lastre_levelyr_tracker_binned.2[2,3] + 
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [3,3] +
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [4,3] +
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [6,3] +
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [7,3] +
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [8,3]),
  B_LB = (GeneBank_reeval_lastre_levelyr_tracker_binned.2[7,3] + 
            GeneBank_reeval_lastre_levelyr_tracker_binned.2 [8,3])/
    (GeneBank_reeval_lastre_levelyr_tracker_binned.2[2,3] + 
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [3,3] +
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [4,3] +
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [6,3] +
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [7,3] +
       GeneBank_reeval_lastre_levelyr_tracker_binned.2 [8,3])
)
#View(Alluvial_Breakdown)

Alluvial_Breakdown.2 <- 
  data.table(
    Less_Confident = (GeneBank_reeval_lastre_levelyr_tracker_binned.2[4,3] + 
                        GeneBank_reeval_lastre_levelyr_tracker_binned.2 [6,3])/
      (GeneBank_reeval_lastre_levelyr_tracker_binned.2[2,3] + 
         GeneBank_reeval_lastre_levelyr_tracker_binned.2 [3,3] +
         GeneBank_reeval_lastre_levelyr_tracker_binned.2 [4,3] +
         GeneBank_reeval_lastre_levelyr_tracker_binned.2 [6,3] +
         GeneBank_reeval_lastre_levelyr_tracker_binned.2 [7,3] +
         GeneBank_reeval_lastre_levelyr_tracker_binned.2 [8,3]),
    More_Confident = (GeneBank_reeval_lastre_levelyr_tracker_binned.2[2,3] + 
                        GeneBank_reeval_lastre_levelyr_tracker_binned.2 [8,3])/
      (GeneBank_reeval_lastre_levelyr_tracker_binned.2[2,3] + 
         GeneBank_reeval_lastre_levelyr_tracker_binned.2 [3,3] +
         GeneBank_reeval_lastre_levelyr_tracker_binned.2 [4,3] +
         GeneBank_reeval_lastre_levelyr_tracker_binned.2 [6,3] +
         GeneBank_reeval_lastre_levelyr_tracker_binned.2 [7,3] +
         GeneBank_reeval_lastre_levelyr_tracker_binned.2 [8,3])
  )
#View(Alluvial_Breakdown.2)

  #2c: Likelihood of Change----
Alluvial_Quant <- data.table(
  P.V = GeneBank_reeval_lastre_levelyr_tracker_binned.2[4,3]/
    (GeneBank_reeval_lastre_levelyr_tracker_binned.2[1,3]+
       GeneBank_reeval_lastre_levelyr_tracker_binned.2[4,3]+
       GeneBank_reeval_lastre_levelyr_tracker_binned.2[7,3]),
  P.B = GeneBank_reeval_lastre_levelyr_tracker_binned.2[7,3]/
    (GeneBank_reeval_lastre_levelyr_tracker_binned.2[1,3]+
       GeneBank_reeval_lastre_levelyr_tracker_binned.2[4,3]+
       GeneBank_reeval_lastre_levelyr_tracker_binned.2[7,3]),
  V.P = GeneBank_reeval_lastre_levelyr_tracker_binned.2[2,3]/
    (GeneBank_reeval_lastre_levelyr_tracker_binned.2[2,3]+
       GeneBank_reeval_lastre_levelyr_tracker_binned.2[5,3]+
       GeneBank_reeval_lastre_levelyr_tracker_binned.2[8,3]),
  V.B = GeneBank_reeval_lastre_levelyr_tracker_binned.2[8,3]/
    (GeneBank_reeval_lastre_levelyr_tracker_binned.2[2,3]+
       GeneBank_reeval_lastre_levelyr_tracker_binned.2[5,3]+
       GeneBank_reeval_lastre_levelyr_tracker_binned.2[8,3]),
  B.P = GeneBank_reeval_lastre_levelyr_tracker_binned.2[3,3]/
    (GeneBank_reeval_lastre_levelyr_tracker_binned.2[3,3]+
       GeneBank_reeval_lastre_levelyr_tracker_binned.2[6,3]+
       GeneBank_reeval_lastre_levelyr_tracker_binned.2[9,3]),
  B.V = GeneBank_reeval_lastre_levelyr_tracker_binned.2[6,3]/
    (GeneBank_reeval_lastre_levelyr_tracker_binned.2[3,3]+
       GeneBank_reeval_lastre_levelyr_tracker_binned.2[6,3]+
       GeneBank_reeval_lastre_levelyr_tracker_binned.2[9,3])
)
View(Alluvial_Quant)

#3: Significance and Confidence Level over Time ----

#Year-by-year analysis for Reevaluated and signficantly changed genes
GeneBank_confyr <- GeneBank_confyr %>% filter (Year >2010)
GeneBank_levelyr <- GeneBank_levelyr %>% filter (Year >2010)
GeneBank_confyr <- data.table(table(GeneBank_sigchange$Significance_Confidence_Indicator, 
                                    GeneBank_sigchange$Year))
names(GeneBank_confyr) [1] <- "Significance_Certainty"
names(GeneBank_confyr) [2] <- "Year"
names(GeneBank_confyr) [3] <- "Number_of_Variants"
ggplot(GeneBank_confyr, aes(fill = Significance_Certainty, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_fill(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("white", "lightcyan2", "lightcyan4"), 
                    name = "Significance Certainty", labels = c( "Uncertain", "Likely Certain", "Certain" ))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

ggplot(GeneBank_confyr, aes(fill = Significance_Certainty, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_stack(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("white", "lightcyan2", "lightcyan4"), 
                    name = "Significance Certainty", labels = c( "Uncertain", "Likely Certain", "Certain" ))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

GeneBank_levelyr <- data.table(table(GeneBank_sigchange$Significance_Level_Indicator, 
                                     GeneBank_sigchange$Year))
names(GeneBank_levelyr) [1] <- "Significance_Level"
names(GeneBank_levelyr) [2] <- "Year"
names(GeneBank_levelyr) [3] <- "Number_of_Variants"
ggplot(GeneBank_levelyr, aes(fill = Significance_Level, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_fill(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("royalblue4", "royalblue3", "royalblue1", "white", 
                               "red1", "red3","red4"), name = "Significance Level", labels = c( "Benign", 
                                                                                                "Bngn/Likely Bngn", "Likely Bngn", "Uncertain/Conflicting", "Likely Pathogenic", "Path/Likely path",  
                                                                                                "Pathogenic"))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))
ggplot(GeneBank_levelyr, aes(fill = Significance_Level, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_stack(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("royalblue4", "royalblue3", "royalblue1", "white", 
                               "red1", "red3", "red4"), name = "Significance Level", labels = c( "Benign", 
                                                                                                 "Bngn/Likely Bngn", "Likely Bngn", "Uncertain/Conflicting", "Likely Pathogenic","Path/Likely path",   
                                                                                                 "Pathogenic"))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

  #3a: Reevaluated and significantly changes variants on only the evaluations leading to a significant change----
GeneBank_sigchange_confyr <- data.table(table(GeneBank_sigchange_changeind$Significance_Confidence_Indicator, 
                                              GeneBank_sigchange_changeind$Year))
names(GeneBank_sigchange_confyr) [1] <- "Significance_Certainty"
names(GeneBank_sigchange_confyr) [2] <- "Year"
names(GeneBank_sigchange_confyr) [3] <- "Number_of_Variants"
GeneBank_sigchange_confyr <- GeneBank_sigchange_confyr %>% filter (Year >2010)
ggplot(GeneBank_sigchange_confyr, aes(fill = Significance_Certainty, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_fill(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("white", "lightcyan2", "lightcyan4"), 
                    name = "Significance Certainty", labels = c( "Uncertain", "Likely Certain", "Certain" ))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))
ggplot(GeneBank_sigchange_confyr, aes(fill = Significance_Certainty, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_stack(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("white", "lightcyan2", "lightcyan4"), 
                    name = "Significance Certainty", labels = c( "Uncertain", "Likely Certain", "Certain" ))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

GeneBank_sigchange_levelyr <- data.table(table(GeneBank_sigchange_changeind$Significance_Level_Indicator, 
                                               GeneBank_sigchange_changeind$Year))
names(GeneBank_sigchange_levelyr) [1] <- "Significance_Level"
names(GeneBank_sigchange_levelyr) [2] <- "Year"
names(GeneBank_sigchange_levelyr) [3] <- "Number_of_Variants"
GeneBank_sigchange_levelyr <- GeneBank_sigchange_levelyr %>% filter (Year > 2010)
ggplot(GeneBank_sigchange_levelyr, aes(fill = Significance_Level, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_fill(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("royalblue4", "royalblue3", "royalblue1", "white", 
                               "red1", "red3","red4"), name = "Significance Level", labels = c( "Benign", 
                                                                                                "Bngn/Likely Bngn", "Likely Bngn", "Uncertain/Conflicting", "Likely Pathogenic", "Path/Likely path",  
                                                                                                "Pathogenic"))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

ggplot(GeneBank_sigchange_levelyr, aes(fill = Significance_Level, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_stack(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("darkolivegreen4", "darkolivegreen3", "darkolivegreen1", "white", 
                               "firebrick1", "firebrick3", "firebrick4"), name = "Significance Level", labels = c( "B", 
                                                                                                                   "LB/B", "LB", "C/VUS", "LP","LP/P", "P"))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))


  #3b: New Evaluations----
GeneBank_sigchange_levelyr <- data.table(table(GeneBankdt_firsteval$Significance_Level_Indicator, 
                                               GeneBankdt_firsteval$Year))
names(GeneBank_sigchange_levelyr) [1] <- "Significance_Level"
names(GeneBank_sigchange_levelyr) [2] <- "Year"
names(GeneBank_sigchange_levelyr) [3] <- "Number_of_Variants"
GeneBank_sigchange_levelyr <- GeneBank_sigchange_levelyr %>% filter (Year > 2010)
ggplot(GeneBank_sigchange_levelyr, aes(fill = Significance_Level, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_fill(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("royalblue4", "royalblue3", "royalblue1", "white", 
                               "red1", "red3","red4"), name = "Significance Level", labels = c( "Benign", 
                                                                                                "Bngn/Likely Bngn", "Likely Bngn", "Uncertain/Conflicting", "Likely Pathogenic", "Path/Likely path",  
                                                                                                "Pathogenic"))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

ggplot(GeneBank_sigchange_levelyr, aes(fill = Significance_Level, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_stack(reverse = TRUE), color = "black")+
  scale_fill_manual(values = c("darkolivegreen4", "darkolivegreen3", "darkolivegreen1", "white", 
                               "firebrick1", "firebrick3", "firebrick4"), name = "Significance Level", labels = c( "B", 
                                                                                                                   "B/LB", "LB", "C/VUS", "LP","P/LP", "P"))+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))
  #3c: Year-by-year analysis for first gene evaluation----
GeneBankdt_first_confyr <- data.table(table(GeneBankdt_firsteval$Significance_Confidence_Indicator, 
                                            GeneBankdt_firsteval$Year))
names(GeneBankdt_first_confyr) [1] <- "Significance_Certainty"
names(GeneBankdt_first_confyr) [2] <- "Year"
names(GeneBankdt_first_confyr) [3] <- "Number_of_Variants"
GeneBankdt_first_confyr <- GeneBankdt_first_confyr %>% filter (Year > 2010)
ggplot(GeneBankdt_first_confyr, aes(fill = Significance_Certainty, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_fill(reverse = TRUE))+
  scale_fill_manual(values = c("white", "lightcyan2", "lightcyan4"), 
                    name = "Significance Certainty", labels = c( "Uncertain", "Likely Certain", "Certain" ))+
  ggtitle("Confidence Level Proportion in Initial Variant Evaluations by Year")+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))
ggplot(GeneBankdt_first_confyr, aes(fill = Significance_Certainty, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_stack(reverse = TRUE))+
  scale_fill_manual(values = c("white", "lightcyan2", "lightcyan4"), 
                    name = "Significance Certainty", labels = c( "Uncertain", "Likely Certain", "Certain" ))+
  ggtitle("Confidence Level Proportion in Initial Variant Evaluations by Year")+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))

GeneBankdt_first_levelyr <- data.table(table(GeneBankdt_firsteval$Significance_Level_Indicator, 
                                             GeneBankdt_firsteval$Year))
names(GeneBankdt_first_levelyr) [1] <- "Significance_Level"
names(GeneBankdt_first_levelyr) [2] <- "Year"
names(GeneBankdt_first_levelyr) [3] <- "Number_of_Variants"
GeneBankdt_first_levelyr <- GeneBankdt_first_levelyr %>% filter (Year > 2010)
ggplot(GeneBankdt_first_levelyr, aes(fill = Significance_Level, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_fill(reverse = TRUE))+
  scale_fill_manual(values = c("royalblue4", "royalblue3", "royalblue1", "white", 
                               "red1", "red3", "red4"), name = "Significance Level", labels = c( "Benign", 
                                                                                                 "Benign/Likely Benign", "Likely Benign", "Uncertain/Conflicting",
                                                                                                 "Likely Pathogenic", "Pathogenic"))+
  ggtitle("Signficance Level Proportion in Initial Variant Evaluations by Year")+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))
ggplot(GeneBankdt_first_levelyr, aes(fill = Significance_Level, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_stack(reverse = TRUE))+
  scale_fill_manual(values = c("royalblue4", "royalblue3", "royalblue1", "white", 
                               "red1", "red3", "red4"), name = "Significance Level", labels = c( "Benign", 
                                                                                                 "Benign/Likely Benign", "Likely Benign", "Uncertain/Conflicting",
                                                                                                 "Likely Pathogenic", "Pathogenic"))+
  ggtitle("Significance Level in Initial Variant Evaluations by Year")+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))

#Year-by-year analysis for only Reevaluations
GeneBankdt_nofirst_confyr <- data.table(table(GeneBankdt_nofirst$Significance_Confidence_Indicator, 
                                              GeneBankdt_nofirst$Year))
names(GeneBankdt_nofirst_confyr) [1] <- "Significance_Certainty"
names(GeneBankdt_nofirst_confyr) [2] <- "Year"
names(GeneBankdt_nofirst_confyr) [3] <- "Number_of_Variants"
ggplot(GeneBankdt_nofirst_confyr, aes(fill = Significance_Certainty, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_fill(reverse = TRUE))+
  scale_fill_manual(values = c("white", "lightcyan2", "lightcyan4"), 
                    name = "Significance Certainty", labels = c( "Uncertain", "Likely Certain", "Certain" ))+
  ggtitle("Confidence Level Proportion in Reevaluated Variants by Year")+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))
ggplot(GeneBankdt_nofirst_confyr, aes(fill = Significance_Certainty, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_stack(reverse = TRUE))+
  scale_fill_manual(values = c("white", "lightcyan2", "lightcyan4"), 
                    name = "Significance Certainty", labels = c( "Uncertain", "Likely Certain", "Certain" ))+
  ggtitle("Confidence Level Proportion in Reevaluated Variants by Year")+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))
GeneBankdt_nofirst_levelyr <- data.table(table(GeneBankdt_nofirst$Significance_Level_Indicator, 
                                               GeneBankdt_nofirst$Year))
names(GeneBankdt_nofirst_levelyr) [1] <- "Significance_Level"
names(GeneBankdt_nofirst_levelyr) [2] <- "Year"
names(GeneBankdt_nofirst_levelyr) [3] <- "Number_of_Variants"
ggplot(GeneBankdt_nofirst_levelyr, aes(fill = Significance_Level, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_fill(reverse = TRUE))+
  scale_fill_manual(values = c("royalblue4", "royalblue3", "royalblue1", "white", 
                               "red1", "red3", "red4"), name = "Significance Level", labels = c( "Benign", 
                                                                                                 "Benign/Likely Benign", "Likely Benign", "Uncertain/Conflicting",
                                                                                                 "Likely Pathogenic", "Pathogenic/Likely pathogenic", "Pathogenic"))+
  ggtitle("Signficance Level Proportion in Reevaluated Variants Evaluations by Year")+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))
ggplot(GeneBankdt_nofirst_levelyr, aes(fill = Significance_Level, x = Year, y = Number_of_Variants))+
  geom_bar(stat = "identity", position = position_stack(reverse = TRUE))+
  scale_fill_manual(values = c("royalblue4", "royalblue3", "royalblue1", "white", 
                               "red1", "red3", "red4"), name = "Significance Level", labels = c( "Benign", 
                                                                                                 "Benign/Likely Benign", "Likely Benign", "Uncertain/Conflicting",
                                                                                                 "Likely Pathogenic", "Pathogenic/Likely pathogenic", "Pathogenic"))+
  ggtitle("Significance Level in Reevaluated Variants Evaluations by Year")+
  ylab("Number of Variants")+
  guides(fill=guide_legend(reverse=TRUE))

#4: Regression Analysis----

#Chi-square testing...
#For relatedness of Year and Significance Level
GeneBank_sigchange_chitbl <- data.table::dcast(GeneBank_sigchange, 
                                               Year~Significance_Level_Indicator, value.var = "Significance_Level_Indicator")
chisq.test(GeneBank_sigchange_chitbl)
fisher.test(GeneBank_sigchange_chitbl, simulate.p.value = TRUE)

#For relatedness of Year and Significance Confidence
GeneBank_sigchange_chitbl2 <- data.table::dcast(GeneBank_sigchange, 
                                                Year~Significance_Confidence_Indicator, value.var = "Significance_Confidence_Indicator")
chisq.test(GeneBank_sigchange_chitbl2)
fisher.test(GeneBank_sigchange_chitbl2, simulate.p.value = TRUE)

#5: Reevaluation Rate over Time----

  #5a: Reevaluation Rate----
GeneBankdt_nofirst_ttable <- data.table(table(GeneBankdt_nofirst$Year))
GeneBankdt_nofirst_ttable <- GeneBankdt_nofirst_ttable %>%
  filter (V1 >= 2011)
names(GeneBankdt_nofirst_ttable)[1] <- "Year"
names(GeneBankdt_nofirst_ttable)[2] <- "reevaluations"
GeneBankdt_firsteval_ttable <- data.table(table(GeneBankdt_firsteval$Year))
GeneBankdt_firsteval_ttable <- GeneBankdt_firsteval_ttable %>%
  filter (V1 >= 2011)
names(GeneBankdt_firsteval_ttable)[1] <- "Year"
names(GeneBankdt_firsteval_ttable)[2] <- "Initial_Evaluations"
GeneBankdt_firsteval_ttable$NumSum <- cumsum(GeneBankdt_firsteval_ttable$Initial_Evaluations)
GeneBankdt_firsteval_ttable <- GeneBankdt_firsteval_ttable %>%
  filter (Year >= 2011)
GeneBank_reevalrate <- merge(x=GeneBankdt_firsteval_ttable, 
                             y=GeneBankdt_nofirst_ttable, by="Year")
GeneBank_reevalrate$Reeval_Rate <- GeneBank_reevalrate$`reevaluations`/
  GeneBank_reevalrate$NumSum
GeneBank_reevalrate <- GeneBank_reevalrate %>%
  mutate(Year = as.numeric(Year))

ggplot(GeneBank_reevalrate, aes(x=Year, y=Reeval_Rate))+
  geom_point(size = 5, color = "blue3")+
  #geom_smooth(method = 'lm', se = FALSE, color = "black", lty = 2)+
  scale_x_continuous(breaks = c(2011, 2013, 2015, 2017, 2019, 2021))+
  scale_y_continuous(limit = c(0, 1))+
  ylab ("Reevaluation Probability")+
  theme(axis.text = element_text(size = 20, family = "Arial", color = "black", face = "bold"),
        axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

  #5b:Clinically Significant Change Rate----
GeneBank_sigchange_changeind_yeartbl <- data.table(table(GeneBank_sigchange_changeind$Year))
GeneBank_sigchange_changeind_yeartbl <- GeneBank_sigchange_changeind_yeartbl %>%
  filter (V1 >= 2011)
names(GeneBank_sigchange_changeind_yeartbl)[1] <- "Year"
names(GeneBank_sigchange_changeind_yeartbl)[2] <- "Reevaluations"
GeneBank_sigchange_changeind_yeartbl$Year <- as.numeric(GeneBank_sigchange_changeind_yeartbl$Year)
GeneBankdt_firsteval_ttable$Year <- as.numeric(GeneBankdt_firsteval_ttable$Year)
GeneBank_reevalrate_sigchange <- merge(x = GeneBank_sigchange_changeind_yeartbl,
                                       y = GeneBankdt_firsteval_ttable, by = "Year")
GeneBank_reevalrate_sigchange$Sig_Change_Rate <- GeneBank_reevalrate_sigchange$`Reevaluations`/
  GeneBank_reevalrate$NumSum

ggplot(GeneBank_reevalrate_sigchange, aes(x=Year, y=Sig_Change_Rate))+
  geom_point(size = 5, color = "blue3")+
  scale_x_continuous(breaks = c(2011, 2013, 2015, 2017, 2019, 2021))+
  scale_y_continuous(limit = c(0, 0.15))+
  #geom_smooth(method = 'lm', se = FALSE, color = "red", lty = 2)+
  ylab ("Significant Change Probability")+
  theme(axis.text = element_text(size = 20, family = "Arial", color = "black", face = "bold"),
        axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

  #5c: Combined figure----
GeneBank_reevalrate_sigchange.2 <- GeneBank_reevalrate_sigchange %>% 
  select("Year", "Sig_Change_Rate")
GeneBank_reevalrate$Year <- as.numeric(GeneBank_reevalrate$Year)
GeneBank_reevalrate_sigchange.2$Year <- as.numeric(GeneBank_reevalrate_sigchange.2$Year)
GeneBank_reevalrate_combined <- merge(x = GeneBank_reevalrate, 
                                      y = GeneBank_reevalrate_sigchange.2, by = "Year")
GeneBank_reevalrate_combined$Comb_Rate <- GeneBank_reevalrate_combined$Sig_Change_Rate/
  GeneBank_reevalrate_combined$Reeval_Rate
ggplot(GeneBank_reevalrate_combined, aes(x=Year, y=Comb_Rate))+
  geom_point(size = 3, color = "blue")+
  scale_x_continuous(breaks = c(2011, 2013, 2015, 2017, 2019))+
  geom_smooth(method = 'lm', se = FALSE, color = "red", lty = 2)+
  ylab ("Significant Changes per Reevaluation")+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))


#6: Predictive Model----
  #6a: For all variants that were Reevaluated----
GeneBank.reeval$ConfLevel <- 
  ifelse(GeneBank.reeval$ClinicalSignificance == "Pathogenic", "3",
         ifelse(GeneBank.reeval$ClinicalSignificance == "Benign", "3", 
                ifelse(GeneBank.reeval$ClinicalSignificance == "Pathogenic/Likely pathogenic", "2", 
                       ifelse(GeneBank.reeval$ClinicalSignificance == "Benign/Likely benign", "2",
                              ifelse(GeneBank.reeval$ClinicalSignificance == "Likely pathogenic", "1", 
                                     ifelse(GeneBank.reeval$ClinicalSignificance == "Likely benign", "1", "0"))))))
GeneBank_reeval_predtbl <- GeneBank.reeval %>% select("Year", "ConfLevel")
GeneBank_reeval_predtbl <- data.table(table(GeneBank_reeval_predtbl$Year, 
                                            GeneBank_reeval_predtbl$ConfLevel))
names(GeneBank_reeval_predtbl)[1] <- "Year"
names(GeneBank_reeval_predtbl)[2] <- "ConfLevel"
names(GeneBank_reeval_predtbl)[3] <- "Number_of_Variants"
GeneBank_reeval_predtbl <- GeneBank_reeval_predtbl %>% filter (Year>=2011)
GeneBank_reeval_predtbl$Year <- as.numeric(GeneBank_reeval_predtbl$Year)
GeneBank_reeval_predtbl$ConfLevel <- as.numeric(GeneBank_reeval_predtbl$ConfLevel)
GeneBank_reeval_predtbl$Number_of_Variants <- as.numeric(GeneBank_reeval_predtbl$Number_of_Variants)
GeneBank_reeval_predtbl$Product <- GeneBank_reeval_predtbl$ConfLevel*
  GeneBank_reeval_predtbl$Number_of_Variants
GeneBank_reeval_predtbl_2011 <- GeneBank_reeval_predtbl %>% filter (Year == 2011)
GeneBank_reeval_predtbl_2012 <- GeneBank_reeval_predtbl %>% filter (Year == 2012)
GeneBank_reeval_predtbl_2013 <- GeneBank_reeval_predtbl %>% filter (Year == 2013)
GeneBank_reeval_predtbl_2014 <- GeneBank_reeval_predtbl %>% filter (Year == 2014)
GeneBank_reeval_predtbl_2015 <- GeneBank_reeval_predtbl %>% filter (Year == 2015)
GeneBank_reeval_predtbl_2016 <- GeneBank_reeval_predtbl %>% filter (Year == 2016)
GeneBank_reeval_predtbl_2017 <- GeneBank_reeval_predtbl %>% filter (Year == 2017)
GeneBank_reeval_predtbl_2018 <- GeneBank_reeval_predtbl %>% filter (Year == 2018)
GeneBank_reeval_predtbl_2019 <- GeneBank_reeval_predtbl %>% filter (Year == 2019)
GeneBank_reeval_predtbl_2020 <- GeneBank_reeval_predtbl %>% filter (Year == 2020)

GeneBank_reeval_predtbl_2011_score <- data.table(sum(GeneBank_reeval_predtbl_2011$Product)/sum(GeneBank_reeval_predtbl_2011$Number_of_Variants))
GeneBank_reeval_predtbl_2012_score <- data.table(sum(GeneBank_reeval_predtbl_2012$Product)/sum(GeneBank_reeval_predtbl_2012$Number_of_Variants))
GeneBank_reeval_predtbl_2013_score <- data.table(sum(GeneBank_reeval_predtbl_2013$Product)/sum(GeneBank_reeval_predtbl_2013$Number_of_Variants))
GeneBank_reeval_predtbl_2014_score <- data.table(sum(GeneBank_reeval_predtbl_2014$Product)/sum(GeneBank_reeval_predtbl_2014$Number_of_Variants))
GeneBank_reeval_predtbl_2015_score <- data.table(sum(GeneBank_reeval_predtbl_2015$Product)/sum(GeneBank_reeval_predtbl_2015$Number_of_Variants))
GeneBank_reeval_predtbl_2016_score <- data.table(sum(GeneBank_reeval_predtbl_2016$Product)/sum(GeneBank_reeval_predtbl_2016$Number_of_Variants))
GeneBank_reeval_predtbl_2017_score <- data.table(sum(GeneBank_reeval_predtbl_2017$Product)/sum(GeneBank_reeval_predtbl_2017$Number_of_Variants))
GeneBank_reeval_predtbl_2018_score <- data.table(sum(GeneBank_reeval_predtbl_2018$Product)/sum(GeneBank_reeval_predtbl_2018$Number_of_Variants))
GeneBank_reeval_predtbl_2019_score <- data.table(sum(GeneBank_reeval_predtbl_2019$Product)/sum(GeneBank_reeval_predtbl_2019$Number_of_Variants))
GeneBank_reeval_predtbl_2020_score <- data.table(sum(GeneBank_reeval_predtbl_2020$Product)/sum(GeneBank_reeval_predtbl_2020$Number_of_Variants))

GeneBank_reeval_predtbl_score <- rbind(GeneBank_reeval_predtbl_2011_score, GeneBank_reeval_predtbl_2012_score)
GeneBank_reeval_predtbl_score <- rbind(GeneBank_reeval_predtbl_score, GeneBank_reeval_predtbl_2013_score)
GeneBank_reeval_predtbl_score <- rbind(GeneBank_reeval_predtbl_score, GeneBank_reeval_predtbl_2014_score)
GeneBank_reeval_predtbl_score <- rbind(GeneBank_reeval_predtbl_score, GeneBank_reeval_predtbl_2015_score)
GeneBank_reeval_predtbl_score <- rbind(GeneBank_reeval_predtbl_score, GeneBank_reeval_predtbl_2016_score)
GeneBank_reeval_predtbl_score <- rbind(GeneBank_reeval_predtbl_score, GeneBank_reeval_predtbl_2017_score)
GeneBank_reeval_predtbl_score <- rbind(GeneBank_reeval_predtbl_score, GeneBank_reeval_predtbl_2018_score)
GeneBank_reeval_predtbl_score <- rbind(GeneBank_reeval_predtbl_score, GeneBank_reeval_predtbl_2019_score)
GeneBank_reeval_predtbl_score <- rbind(GeneBank_reeval_predtbl_score, GeneBank_reeval_predtbl_2020_score)

names(GeneBank_reeval_predtbl_score)[1] <- "Confidence_Score"

GeneBank_reeval_predtbl_score$Year <- c(2011, 2012, 2013, 2014, 2015, 2016,
                                        2017, 2018, 2019, 2020)

ggplot(GeneBank_reeval_predtbl_score, aes(x=Year, y=Confidence_Score))+
  geom_point()+
  stat_smooth(method='lm', fullrange = TRUE)+
  scale_x_continuous(limits = c(2011, 2025), breaks = c(2011, 2013, 2015, 2017,
                                                        2019, 2021, 2023))+
  ylab("Confidence Score")+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

  #6b: For ALL variants----
GeneBankdt.2 <- data.table(GeneBankdt)
GeneBankdt.2$ConfLevel <- 
  ifelse(GeneBankdt.2$ClinicalSignificance == "Pathogenic", "3",
         ifelse(GeneBankdt.2$ClinicalSignificance == "Benign", "3", 
                ifelse(GeneBankdt.2$ClinicalSignificance == "Pathogenic/Likely pathogenic", "2", 
                       ifelse(GeneBankdt.2$ClinicalSignificance == "Benign/Likely benign", "2",
                              ifelse(GeneBankdt.2$ClinicalSignificance == "Likely pathogenic", "1", 
                                     ifelse(GeneBankdt.2$ClinicalSignificance == "Likely benign", "1", "0"))))))
GeneBankdt.3 <- GeneBankdt.2 %>% select("Year", "ConfLevel")

GeneBankdt.3 <- GeneBankdt.3 %>% filter (Year>=2011)
GeneBankdt.3$Year <- as.numeric(GeneBankdt.3$Year)
GeneBankdt.3$ConfLevel <- as.numeric(GeneBankdt.3$ConfLevel)
GeneBankdt.3$Product <- GeneBankdt.3$ConfLevel

#Mean Confidence Score
sum(GeneBankdt.3$Product)/sum(GeneBankdt.3$Number_of_Variants)

GeneBank_predtbl_2011 <- GeneBankdt.3 %>% filter (Year == 2011)
GeneBank_predtbl_2012 <- GeneBankdt.3 %>% filter (Year == 2012)
GeneBank_predtbl_2013 <- GeneBankdt.3 %>% filter (Year == 2013)
GeneBank_predtbl_2014 <- GeneBankdt.3 %>% filter (Year == 2014)
GeneBank_predtbl_2015 <- GeneBankdt.3 %>% filter (Year == 2015)
GeneBank_predtbl_2016 <- GeneBankdt.3 %>% filter (Year == 2016)
GeneBank_predtbl_2017 <- GeneBankdt.3 %>% filter (Year == 2017)
GeneBank_predtbl_2018 <- GeneBankdt.3 %>% filter (Year == 2018)
GeneBank_predtbl_2019 <- GeneBankdt.3 %>% filter (Year == 2019)
GeneBank_predtbl_2020 <- GeneBankdt.3 %>% filter (Year == 2020)
GeneBank_predtbl_2021 <- GeneBankdt.3 %>% filter (Year == 2021)

GeneBank_predtbl_2011_score <- data.table(sum(GeneBank_predtbl_2011$Product)/count(GeneBank_predtbl_2011))
GeneBank_predtbl_2011_score$SE <- sd(GeneBank_predtbl_2011$ConfLevel)/sqrt(count(GeneBank_predtbl_2011))
GeneBank_predtbl_2011_score$Year <- 2011
GeneBank_predtbl_2012_score <- data.table(sum(GeneBank_predtbl_2012$Product)/count(GeneBank_predtbl_2012))
GeneBank_predtbl_2012_score$SE <- sd(GeneBank_predtbl_2012$ConfLevel)/sqrt(count(GeneBank_predtbl_2012))
GeneBank_predtbl_2012_score$Year <- 2012
GeneBank_predtbl_2013_score <- data.table(sum(GeneBank_predtbl_2013$Product)/count(GeneBank_predtbl_2013))
GeneBank_predtbl_2013_score$SE <- sd(GeneBank_predtbl_2013$ConfLevel)/sqrt(count(GeneBank_predtbl_2013))
GeneBank_predtbl_2013_score$Year <- 2013
GeneBank_predtbl_2014_score <- data.table(sum(GeneBank_predtbl_2014$Product)/count(GeneBank_predtbl_2014))
GeneBank_predtbl_2014_score$SE <- sd(GeneBank_predtbl_2014$ConfLevel)/sqrt(count(GeneBank_predtbl_2014))
GeneBank_predtbl_2014_score$Year <- 2014
GeneBank_predtbl_2015_score <- data.table(sum(GeneBank_predtbl_2015$Product)/count(GeneBank_predtbl_2015))
GeneBank_predtbl_2015_score$SE <- sd(GeneBank_predtbl_2015$ConfLevel)/sqrt(count(GeneBank_predtbl_2015))
GeneBank_predtbl_2015_score$Year <- 2015
GeneBank_predtbl_2016_score <- data.table(sum(GeneBank_predtbl_2016$Product)/count(GeneBank_predtbl_2016))
GeneBank_predtbl_2016_score$SE <- sd(GeneBank_predtbl_2016$ConfLevel)/sqrt(count(GeneBank_predtbl_2016))
GeneBank_predtbl_2016_score$Year <- 2016
GeneBank_predtbl_2017_score <- data.table(sum(GeneBank_predtbl_2017$Product)/count(GeneBank_predtbl_2017))
GeneBank_predtbl_2017_score$SE <- sd(GeneBank_predtbl_2017$ConfLevel)/sqrt(count(GeneBank_predtbl_2017))
GeneBank_predtbl_2017_score$Year <- 2017
GeneBank_predtbl_2018_score <- data.table(sum(GeneBank_predtbl_2018$Product)/count(GeneBank_predtbl_2018))
GeneBank_predtbl_2018_score$SE <- sd(GeneBank_predtbl_2018$ConfLevel)/sqrt(count(GeneBank_predtbl_2018))
GeneBank_predtbl_2018_score$Year <- 2018
GeneBank_predtbl_2019_score <- data.table(sum(GeneBank_predtbl_2019$Product)/count(GeneBank_predtbl_2019))
GeneBank_predtbl_2019_score$SE <- sd(GeneBank_predtbl_2019$ConfLevel)/sqrt(count(GeneBank_predtbl_2019))
GeneBank_predtbl_2019_score$Year <- 2019
GeneBank_predtbl_2020_score <- data.table(sum(GeneBank_predtbl_2020$Product)/count(GeneBank_predtbl_2020))
GeneBank_predtbl_2020_score$SE <- sd(GeneBank_predtbl_2020$ConfLevel)/sqrt(count(GeneBank_predtbl_2020))
GeneBank_predtbl_2020_score$Year <- 2020
GeneBank_predtbl_2021_score <- data.table(sum(GeneBank_predtbl_2021$Product)/count(GeneBank_predtbl_2021))
GeneBank_predtbl_2021_score$SE <- sd(GeneBank_predtbl_2021$ConfLevel)/sqrt(count(GeneBank_predtbl_2021))
GeneBank_predtbl_2021_score$Year <- 2021

GeneBank_predtbl_score <- rbind(GeneBank_predtbl_2011_score, GeneBank_predtbl_2012_score,
                                GeneBank_predtbl_2013_score, GeneBank_predtbl_2014_score,
                                GeneBank_predtbl_2015_score, GeneBank_predtbl_2016_score,
                                GeneBank_predtbl_2017_score, GeneBank_predtbl_2018_score, 
                                GeneBank_predtbl_2019_score, GeneBank_predtbl_2020_score,
                                GeneBank_predtbl_2021_score)

names(GeneBank_predtbl_score)[1] <- "Confidence_Score"

a <- ggplot(GeneBank_predtbl_score, color = "black", aes(x=Year, y=Confidence_Score))+
  geom_point(fill = "blue", shape = 21, size = 7, colour = "blue")+
  geom_errorbar(aes(ymin=Confidence_Score-SE, ymax=Confidence_Score+SE), width=.5,
                position=position_dodge(0.9), size = 0.8)+
  scale_x_continuous(limits = c(2010.5, 2021.5), breaks = c(2011, 2013, 2015, 2017,
                                                        2019, 2021))+
  scale_y_continuous(limit = c(0, 2.3))+
  ylab("Confidence Score")+
  theme(axis.text = element_text(size = 28, family = "Arial", color = "black", face = "bold"),
        axis.title.x = element_text(size = 28, face = "bold"),
        axis.title.y = element_text(size = 28, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(linewidth = 1.5, color = "black"),
        text = element_text(size = 28, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", linewidth = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 28, face = "bold"))

a
png(file = "/Users/michaelrosamilia/Downloads/ClinVarCM_Fig3.1.png", width = 1000, height = 600)
a
dev.off()

ggplot(GeneBank_predtbl_score, aes(x=Year, y=Confidence_Score))+
  geom_point(size = 5)+
  stat_smooth(method='lm', fullrange = TRUE, lty = 2, se = FALSE)+
  scale_x_continuous(limits = c(2011, 2021), breaks = c(2011, 2013, 2015, 2017,
                                                        2019, 2021))+
  scale_y_continuous(limit = c(0, 2.3))+
  ylab("Confidence Score")+
  theme(axis.text = element_text(size = 20, family = "Arial", color = "black", face = "bold"),
        axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

    #6b.1: For ALL variants (histogram)----
GeneBank_scorebyyear <- GeneBankdt.2 %>% select("Year", "ConfLevel")
GeneBank_scorebyyear <- GeneBank_scorebyyear %>% filter(Year>=2011)
GeneBank_scorebyyear_tbl <- data.table(table(GeneBank_scorebyyear$Year, 
                                             GeneBank_scorebyyear$ConfLevel))
names(GeneBank_scorebyyear_tbl)[1] <- "Year"
names(GeneBank_scorebyyear_tbl)[2] <- "Confidence_Score"
names(GeneBank_scorebyyear_tbl)[3] <- "Number_of_Variants"
GeneBank_scorebyyear_tbl$Year <- as.numeric(GeneBank_scorebyyear_tbl$Year)
GeneBank_scorebyyear_tbl$Confidence_Score <- as.numeric(GeneBank_scorebyyear_tbl$Confidence_Score)
GeneBank_scorebyyear_tbl$Number_of_Variants <- 
  as.numeric(GeneBank_scorebyyear_tbl$Number_of_Variants)
GeneBank_totalbyyear <- GeneBank_scorebyyear_tbl %>% group_by(Year) %>% 
  summarise(Total = sum(Number_of_Variants))
GeneBank_scorebyyear_tbl <- merge(GeneBank_scorebyyear_tbl, GeneBank_totalbyyear, 
                                  by = "Year")
GeneBank_scorebyyear_tbl$Prop <- GeneBank_scorebyyear_tbl$Number_of_Variants/
  GeneBank_scorebyyear_tbl$Total
GeneBank_scorebyyear_tbl$Confidence_Score <- as.factor(GeneBank_scorebyyear_tbl$Confidence_Score)


b <- ggplot(GeneBank_scorebyyear_tbl, aes(fill = Confidence_Score, x=Year, y= Prop))+
  geom_bar(position = position_fill(reverse = TRUE), stat = "identity", orientation = "x", 
           color = "black")+
  scale_fill_manual(values = c("white", "lightcyan2", "lightcyan3", "lightcyan4"), 
                    name = "Confidence Score", labels = c( "Uncertain", "Low Certainty", "Moderate Certainty", "High Certainty" ))+
  scale_x_continuous(breaks = c(2011, 2013, 2015, 2017,
                                                        2019, 2021))+
  ylab("Proportion of Variants")+
  theme(axis.text = element_text(size = 28, family = "Arial", color = "black", face = "bold"),
        axis.title.x = element_text(size = 28, face = "bold"),
        axis.title.y = element_text(size = 28, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(linewidth = 1.5, color = "black"),
        text = element_text(size = 28, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", linewidth = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 28, face = "bold"))
b
png(file = "/Users/michaelrosamilia/Downloads/ClinVarCM_Supp3B.png", width = 1000, height = 600)
b
dev.off()

  #6c: For Clinically Significant Changes----
GeneBank_sigchange_changeind.2 <- data.table(GeneBank_sigchange_changeind)
GeneBank_sigchange_changeind.2$ConfLevel <- 
  ifelse(GeneBank_sigchange_changeind.2$ClinicalSignificance == "Pathogenic", "3",
         ifelse(GeneBank_sigchange_changeind.2$ClinicalSignificance == "Benign", "3", 
                ifelse(GeneBank_sigchange_changeind.2$ClinicalSignificance == "Pathogenic/Likely pathogenic", "2", 
                       ifelse(GeneBank_sigchange_changeind.2$ClinicalSignificance == "Benign/Likely benign", "2",
                              ifelse(GeneBank_sigchange_changeind.2$ClinicalSignificance == "Likely pathogenic", "1", 
                                     ifelse(GeneBank_sigchange_changeind.2$ClinicalSignificance == "Likely benign", "1", "0"))))))
GeneBank_predtbl <- GeneBank_sigchange_changeind.2 %>% select("Year", "ConfLevel")
GeneBank_predtbl <- data.table(table(GeneBank_predtbl$Year, 
                                     GeneBank_predtbl$ConfLevel))
names(GeneBank_predtbl)[1] <- "Year"
names(GeneBank_predtbl)[2] <- "ConfLevel"
names(GeneBank_predtbl)[3] <- "Number_of_Variants"
GeneBank_predtbl <- GeneBank_predtbl %>% filter (Year>=2011)
GeneBank_predtbl$Year <- as.numeric(GeneBank_predtbl$Year)
GeneBank_predtbl$ConfLevel <- as.numeric(GeneBank_predtbl$ConfLevel)
GeneBank_predtbl$Number_of_Variants <- as.numeric(GeneBank_predtbl$Number_of_Variants)
GeneBank_predtbl$Product <- GeneBank_predtbl$ConfLevel*
  GeneBank_predtbl$Number_of_Variants
GeneBank_predtbl_2011 <- GeneBank_predtbl %>% filter (Year == 2011)
GeneBank_predtbl_2012 <- GeneBank_predtbl %>% filter (Year == 2012)
GeneBank_predtbl_2013 <- GeneBank_predtbl %>% filter (Year == 2013)
GeneBank_predtbl_2014 <- GeneBank_predtbl %>% filter (Year == 2014)
GeneBank_predtbl_2015 <- GeneBank_predtbl %>% filter (Year == 2015)
GeneBank_predtbl_2016 <- GeneBank_predtbl %>% filter (Year == 2016)
GeneBank_predtbl_2017 <- GeneBank_predtbl %>% filter (Year == 2017)
GeneBank_predtbl_2018 <- GeneBank_predtbl %>% filter (Year == 2018)
GeneBank_predtbl_2019 <- GeneBank_predtbl %>% filter (Year == 2019)
GeneBank_predtbl_2020 <- GeneBank_predtbl %>% filter (Year == 2020)

GeneBank_predtbl_2011_score <- data.table(sum(GeneBank_predtbl_2011$Product)/sum(GeneBank_predtbl_2011$Number_of_Variants))
GeneBank_predtbl_2012_score <- data.table(sum(GeneBank_predtbl_2012$Product)/sum(GeneBank_predtbl_2012$Number_of_Variants))
GeneBank_predtbl_2013_score <- data.table(sum(GeneBank_predtbl_2013$Product)/sum(GeneBank_predtbl_2013$Number_of_Variants))
GeneBank_predtbl_2014_score <- data.table(sum(GeneBank_predtbl_2014$Product)/sum(GeneBank_predtbl_2014$Number_of_Variants))
GeneBank_predtbl_2015_score <- data.table(sum(GeneBank_predtbl_2015$Product)/sum(GeneBank_predtbl_2015$Number_of_Variants))
GeneBank_predtbl_2016_score <- data.table(sum(GeneBank_predtbl_2016$Product)/sum(GeneBank_predtbl_2016$Number_of_Variants))
GeneBank_predtbl_2017_score <- data.table(sum(GeneBank_predtbl_2017$Product)/sum(GeneBank_predtbl_2017$Number_of_Variants))
GeneBank_predtbl_2018_score <- data.table(sum(GeneBank_predtbl_2018$Product)/sum(GeneBank_predtbl_2018$Number_of_Variants))
GeneBank_predtbl_2019_score <- data.table(sum(GeneBank_predtbl_2019$Product)/sum(GeneBank_predtbl_2019$Number_of_Variants))
GeneBank_predtbl_2020_score <- data.table(sum(GeneBank_predtbl_2020$Product)/sum(GeneBank_predtbl_2020$Number_of_Variants))

GeneBank_predtbl_score <- rbind(GeneBank_predtbl_2011_score, GeneBank_predtbl_2012_score)
GeneBank_predtbl_score <- rbind(GeneBank_predtbl_score, GeneBank_predtbl_2013_score)
GeneBank_predtbl_score <- rbind(GeneBank_predtbl_score, GeneBank_predtbl_2014_score)
GeneBank_predtbl_score <- rbind(GeneBank_predtbl_score, GeneBank_predtbl_2015_score)
GeneBank_predtbl_score <- rbind(GeneBank_predtbl_score, GeneBank_predtbl_2016_score)
GeneBank_predtbl_score <- rbind(GeneBank_predtbl_score, GeneBank_predtbl_2017_score)
GeneBank_predtbl_score <- rbind(GeneBank_predtbl_score, GeneBank_predtbl_2018_score)
GeneBank_predtbl_score <- rbind(GeneBank_predtbl_score, GeneBank_predtbl_2019_score)
GeneBank_predtbl_score <- rbind(GeneBank_predtbl_score, GeneBank_predtbl_2020_score)

names(GeneBank_predtbl_score)[1] <- "Confidence_Score"

GeneBank_predtbl_score$Year <- c(2011, 2012, 2013, 2014, 2015, 2016,
                                 2017, 2018, 2019, 2020)
GeneBank_predtbl_score <- GeneBank_predtbl_score %>%
  filter(Year <2020)

ggplot(GeneBank_predtbl_score, aes(x=Year, y=Confidence_Score))+
  geom_point(size = 2.5)+
  stat_smooth(method='lm', fullrange = TRUE, lty = 2)+
  scale_x_continuous(limits = c(2011, 2023), breaks = c(2011, 2013, 2015, 2017,
                                                        2019, 2021, 2023))+
  ylab("Confidence Score")+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

ggplot(GeneBank_predtbl_score, aes(x=Year, y=Confidence_Score))+
  geom_point(size = 2.5, color = "black")+
  scale_x_continuous(limits = c(2011, 2021), breaks = c(2011, 2013, 2015, 2017,
                                                        2019, 2021))+
  scale_y_continuous(limit = c(0, 2.3))+
  ylab("Confidence Score")+
  theme(axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))

#7: Density Plot of Change Odds----
Tool3 <- GeneBank_sigchange %>% select(AlleleID, ID)
Tool3 <- Tool3[match(unique(Tool3$AlleleID), Tool3$AlleleID),]
Tool3 <- Tool3 %>% select(ID)
GeneBank_sigchange_bygene <- merge(x = Tool3, y = GeneBank_sigchange, by = "ID", all.x = TRUE)
GeneBank_sigchange_bygene <- data.table(table(GeneBank_sigchange_bygene$GeneSymbol))
GeneBank_sigchange_bygene <- GeneBank_sigchange_bygene %>% filter(V1 != "-")
names(GeneBank_sigchange_bygene)[
  names(GeneBank_sigchange_bygene) == "V1"] <- "GeneSymbol"
names(GeneBank_sigchange_bygene)[
  names(GeneBank_sigchange_bygene) == "N"] <- "N1"
GeneBank_sigchange_bygene <- GeneBank_sigchange_bygene[!grepl(";", GeneBank_sigchange_bygene$GeneSymbol), ]

Tool4 <- GeneBankdt%>% select(AlleleID, ID)
Tool4 <- Tool4[match(unique(Tool4$AlleleID), Tool4$AlleleID),]
Tool4 <- Tool4 %>% select(ID)
GeneBankdt_bygene <- merge(x = Tool4, y = GeneBankdt, by = "ID", all.x = TRUE)
GeneBankdt_bygene <- data.table(table(GeneBankdt_bygene$GeneSymbol))
GeneBankdt_bygene <- GeneBankdt_bygene %>% filter(V1 != "-")
GeneBankdt_bygene <- GeneBankdt_bygene %>% filter(V1 != "")
names(GeneBankdt_bygene)[
  names(GeneBankdt_bygene) == "V1"] <- "GeneSymbol"
GeneBankdt_bygene <- GeneBankdt_bygene[!grepl(";", GeneBankdt_bygene$GeneSymbol), ]
GeneBankdt_bygene <- GeneBankdt_bygene %>% filter(N>=50)

GeneBank_sigchange_varfreq <- merge(x = GeneBank_sigchange_bygene, 
                                    y = GeneBankdt_bygene, by = "GeneSymbol", all.x = TRUE)
GeneBank_sigchange_varfreq$N2 <- GeneBank_sigchange_varfreq$N1/GeneBank_sigchange_varfreq$N
GeneBank_sigchange_varfreq <- 
  GeneBank_sigchange_varfreq[complete.cases(GeneBank_sigchange_varfreq),]
GeneBank_sigchange_varfreq.2 <- GeneBank_sigchange_varfreq %>% 
  select(GeneSymbol, N2, N)
GeneBankdt_bygene.2 <- GeneBankdt_bygene %>% select(GeneSymbol)
GeneBank_sigchange_bygene.2 <- GeneBank_sigchange_bygene %>% select(GeneSymbol)
GeneBank_nochange_bygene <- setdiff(GeneBankdt_bygene.2, GeneBank_sigchange_bygene.2)
GeneBank_nochange_bygene <- merge(x = GeneBank_nochange_bygene, GeneBankdt_bygene, by = "GeneSymbol")
GeneBank_nochange_bygene$N2 <- 0
GeneBank_sigchange_varfreq.3 <- rbind(GeneBank_sigchange_varfreq.2, GeneBank_nochange_bygene)

p<- ggplot(GeneBank_sigchange_varfreq.3, aes(x = N2))+
  geom_density(color = "black", fill = "blue", alpha = 0.5)+
  xlab("Proportion of Variants with Significant Change")+
  ylab("Number of Genes")+
  theme(axis.text = element_text(size = 20, family = "Arial", color = "black", face = "bold"),
        axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))
p+ geom_vline(aes(xintercept=median(N2)),
              color="black", linetype="dashed", size=1.5)+
  geom_vline(aes(xintercept = 0.052), color = "black", linetype = "dashed",
             size = 1.0)+
  geom_vline(aes(xintercept = 0.073), color = "black", linetype = "dashed",
             size = 1.0)+
  geom_vline(aes(xintercept = 0.079), color = "black", linetype = "dashed",
             size = 1.0)
summary(GeneBank_sigchange_varfreq.3$N2)
quantile(GeneBank_sigchange_varfreq.3$N2, c(0.593, 0.687, 0.858, 0.892))

q<-ggplot(GeneBank_sigchange_varfreq.3, aes(x=N2)) + 
  geom_histogram(binwidth = 0.025, color="black", fill="white")+
  xlab("Proportion of Variants with Significant Change")+
  ylab("Number of Genes")+
  theme(axis.text = element_text(size = 20, family = "Arial", color = "black", face = "bold"),
        axis.title.x = element_text(size = 20, face = "bold"),
        axis.title.y = element_text(size = 20, face = "bold"),
        axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        text = element_text(size = 20, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "bottom", legend.text = element_text(size = 16, family = "Arial"), 
        legend.box.background = element_rect(color = "black", size = 1.5),
        legend.title = element_text(size = 20, face = "bold"))
q

    #Explanation for zero-weighting----
GeneBank_sigchange_varfreq_0 <- GeneBank_sigchange_varfreq.3 %>%
  filter(N2 == 0) %>% select(GeneSymbol)

GeneBank_nochangegenes <- merge(GeneBank_sigchange_varfreq_0, GeneBankdt, by = "GeneSymbol")
eval_freq_nochange <- data.table(table (GeneBank_nochangegenes$AlleleID))
AvgReeval_nochange <- mean(eval_freq_nochange$N)
summary(GeneBank_nochangegenes$Year)
summary(GeneBankdt$Year)
par(mfrow = c(2,1))
hist(GeneBank_nochangegenes$Year)
hist(GeneBankdt$Year)



#8: GnomAD MAF Analysis----
  #8a: Create a gnomAD file for all CM genes (each file is a downloaded csv directly from gnomAD)----
GnomADBank1 <- read.csv("GnomAD_TTN.csv")
GnomADBank2 <- read.csv("GnomAD_MYH7.csv")
GnomADBank3 <- read.csv("GnomAD_MYBPC3.csv")
GnomADBank4 <- read.csv("GnomAD_TNNT2.csv")
GnomADBank5 <- read.csv("GnomAD_TNNI3.csv")
GnomADBank6 <- read.csv("GnomAD_MYL2.csv")
GnomADBank7 <- read.csv("GnomAD_MYL3.csv")
GnomADBank8 <- read.csv("GnomAD_PKP2.csv")
GnomADBank9 <- read.csv("GnomAD_TNNC1.csv")
GnomADBank10 <- read.csv("GnomAD_DSP.csv")
GnomADBank11 <- read.csv("GnomAD_JUP.csv")
GnomADBank12 <- read.csv("GnomAD_TMEM43.csv")
GnomADBank13 <- read.csv("GnomAD_DSG2.csv")
GnomADBank14 <- read.csv("GnomAD_DSC2.csv")
GnomADBank15 <- read.csv("GnomAD_TPM1.csv")
GnomADBank16 <- read.csv("GnomAD_ACTC1.csv")
GnomADBank <- rbind(GnomADBank1, GnomADBank2, GnomADBank3, GnomADBank4, GnomADBank5,
                    GnomADBank6, GnomADBank7, GnomADBank8, GnomADBank9, GnomADBank10,
                    GnomADBank11, GnomADBank12, GnomADBank13, GnomADBank14, GnomADBank15,
                    GnomADBank16)

  #8b: Merge data sets for downgraded variants----
GeneBank_reeval_lastre_tracker.2 <- merge (x=GeneBankdt_firsteval, 
                                         y= GeneBank_nofirst_lastre, by = "AlleleID")


PathNums <- c(3,2,1)

NonPathNums <- c(0,-1,-2,-3)

GeneBank_reeval_lastre_tracker.2 <- filter(GeneBank_reeval_lastre_tracker.2,
                                           Significance_Level_Indicator %in% PathNums)
GeneBank_reeval_lastre_tracker.2 <- filter(GeneBank_reeval_lastre_tracker.2,
                                           Significance_Level_Indicator_Final %in% NonPathNums)
GeneBank_reeval_lastre_tracker.2 <- GeneBank_reeval_lastre_tracker.2 %>% 
  select(AlleleID, GeneSymbol)
GeneBank_reeval_lastre_tracker.2<- distinct(GeneBank_reeval_lastre_tracker.2)


GeneBank_VarID <- read.delim("variation_allele.2.txt") #file transposing variation to allele ID, publically available on ClinVar
GeneBank_VarID <- GeneBank_VarID %>% rename("VariationID" = "X.VariationID")
GeneBank_VarID <- GeneBank_VarID %>% select(AlleleID, VariationID)
GeneBank_VarAllele <- merge(GeneBank_reeval_lastre_tracker.2, GeneBank_VarID, 
                            by = "AlleleID")
GeneBank_VarAllele <- distinct(GeneBank_VarAllele)

GeneBank_VarAllele <- rename(GeneBank_VarAllele, c("ClinVar.Variation.ID" = "VariationID"))

GnomAD_downgrades <- merge(GeneBank_VarAllele, GnomADBank, 
                           by = "ClinVar.Variation.ID")

  #8c: Calculate MAF by European vs non-European----
GnomAD_downgrades$NonEuropean_MinorAlleleTotal <- GnomAD_downgrades$Allele.Count.African.African.American +
  GnomAD_downgrades$Allele.Count.Latino.Admixed.American + 
  GnomAD_downgrades$Allele.Count.East.Asian + GnomAD_downgrades$Allele.Count.Other +
  GnomAD_downgrades$Allele.Count.Ashkenazi.Jewish + GnomAD_downgrades$Allele.Count.South.Asian

GnomAD_downgrades$European_MinorAlleleTotal <- GnomAD_downgrades$Allele.Count.European..Finnish. +
   GnomAD_downgrades$Allele.Count.European..non.Finnish.

GnomAD_downgrades$NonEuropean_AlleleTotal <- GnomAD_downgrades$Allele.Number.African.African.American +
  GnomAD_downgrades$Allele.Number.Latino.Admixed.American + 
  GnomAD_downgrades$Allele.Number.East.Asian + GnomAD_downgrades$Allele.Number.Other +
  GnomAD_downgrades$Allele.Number.South.Asian + GnomAD_downgrades$Allele.Number.Ashkenazi.Jewish 

GnomAD_downgrades$European_AlleleTotal <- GnomAD_downgrades$Allele.Number.European..Finnish. +
  GnomAD_downgrades$Allele.Number.European..non.Finnish.

GnomAD_downgrades$AA_MAF <- GnomAD_downgrades$Allele.Count.African.African.American/
  GnomAD_downgrades$Allele.Number.African.African.American

GnomAD_downgrades$LA_MAF <- GnomAD_downgrades$Allele.Count.Latino.Admixed.American/
  GnomAD_downgrades$Allele.Number.Latino.Admixed.American

GnomAD_downgrades$EA_MAF <- GnomAD_downgrades$Allele.Count.East.Asian/
  GnomAD_downgrades$Allele.Number.East.Asian

GnomAD_downgrades$SA_MAF <- GnomAD_downgrades$Allele.Count.South.Asian/
  GnomAD_downgrades$Allele.Number.South.Asian

GnomAD_downgrades$AJ_MAF <- GnomAD_downgrades$Allele.Count.Ashkenazi.Jewish/
  GnomAD_downgrades$Allele.Number.Ashkenazi.Jewish


GnomAD_downgrades$NonEuropean_MAF <- GnomAD_downgrades$NonEuropean_MinorAlleleTotal/
  GnomAD_downgrades$NonEuropean_AlleleTotal
GnomAD_downgrades$European_MAF <- GnomAD_downgrades$European_MinorAlleleTotal/
  GnomAD_downgrades$European_AlleleTotal

GnomAD_downgrades_trimmed <- GnomAD_downgrades %>% 
  select(ClinVar.Variation.ID, AlleleID, GeneSymbol, NonEuropean_MAF, European_MAF,
        AA_MAF, LA_MAF, EA_MAF, SA_MAF, AJ_MAF)

GnomAD_downgrades_trimmed$SA_MAF <- str_replace_all(GnomAD_downgrades_trimmed$SA_MAF, fixed("NaN"), "0")



  #8d: Count Downgraded Variants with high MAF in Non-Europeans vs Europeans----
#High MAF in non-Europeans
prop_downgrade <- data.table(sum(GnomAD_downgrades_trimmed$NonEuropean_MAF > 1E-4 | 
      GnomAD_downgrades_trimmed$AA_MAF > 1E-4 |
      GnomAD_downgrades_trimmed$LA_MAF > 1E-4 |
      GnomAD_downgrades_trimmed$EA_MAF > 1E-4 |
      GnomAD_downgrades_trimmed$SA_MAF > 1E-4 |
      GnomAD_downgrades_trimmed$AJ_MAF > 1E-4)/
nrow(GnomAD_downgrades_trimmed))


#High MAF in Europeans
prop_downgrade$European <- sum(GnomAD_downgrades_trimmed$European_MAF > 1E-4)/
  nrow(GnomAD_downgrades_trimmed)

prop_downgrade <- data.table(t(prop_downgrade))
prop_downgrade$Ancestry <- c("NonEuropean", "European")

e <- ggplot(prop_downgrade, aes(fill = Ancestry, x = Ancestry, y = V1))+
  geom_bar(stat = "identity", color = "black")+
  geom_errorbar(aes(x = Ancestry, ymin = V1 - 1.96*sqrt((V1*(1-V1))/187), ymax = V1 + 1.96*sqrt((V1*(1-V1))/187)),
                width = 0.25, size = 1.0)+
  scale_fill_manual(values = c("white", "dodgerblue3"))+
  xlab("Ancestry")+
  ylab("Proportion Donwngraded Variants MAF >1E-04")+
  theme(axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        axis.text = element_text(size = 26, family = "Arial", color = "black", face = "bold"),
        text = element_text(size = 26, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "none")

e




  #8e: Evaluation for all initially P/LP variants (not just downgrades)----
GeneBank_reeval_lastre_tracker.3 <- merge (x=GeneBankdt_firsteval, 
                                           y= GeneBank_nofirst_lastre, by = "AlleleID")


PathNums <- c(3,2,1)

GeneBank_reeval_lastre_tracker.3 <- filter(GeneBank_reeval_lastre_tracker.3,
                                           Significance_Level_Indicator %in% PathNums)
GeneBank_reeval_lastre_tracker.3 <- GeneBank_reeval_lastre_tracker.3 %>% 
  select(AlleleID, GeneSymbol)
GeneBank_reeval_lastre_tracker.3<- distinct(GeneBank_reeval_lastre_tracker.3)


GeneBank_VarID <- read.delim("variation_allele.txt")#transposition of variation to allele ID publically available on ClinVar
GeneBank_VarID <- GeneBank_VarID %>% rename("VariationID" = "X.VariationID")
GeneBank_VarID <- GeneBank_VarID %>% select(AlleleID, VariationID)
GeneBank_VarAllele.2 <- merge(GeneBank_reeval_lastre_tracker.3, GeneBank_VarID, 
                            by = "AlleleID")
GeneBank_VarAllele.2 <- distinct(GeneBank_VarAllele.2)

GeneBank_VarAllele.2 <- rename(GeneBank_VarAllele.2, c("ClinVar.Variation.ID" = "VariationID"))

GnomAD_initialplp <- merge(GeneBank_VarAllele.2, GnomADBank, 
                           by = "ClinVar.Variation.ID")

GnomAD_initialplp$NonEuropean_MinorAlleleTotal <- GnomAD_initialplp$Allele.Count.African.African.American +
  GnomAD_initialplp$Allele.Count.Latino.Admixed.American + 
  GnomAD_initialplp$Allele.Count.East.Asian + GnomAD_initialplp$Allele.Count.Other +
  GnomAD_initialplp$Allele.Count.Ashkenazi.Jewish + GnomAD_initialplp$Allele.Count.South.Asian

GnomAD_initialplp$European_MinorAlleleTotal <- GnomAD_initialplp$Allele.Count.European..Finnish. +
  GnomAD_initialplp$Allele.Count.European..non.Finnish.

GnomAD_initialplp$NonEuropean_AlleleTotal <- GnomAD_initialplp$Allele.Number.African.African.American +
  GnomAD_initialplp$Allele.Number.Latino.Admixed.American + 
  GnomAD_initialplp$Allele.Number.East.Asian + GnomAD_initialplp$Allele.Number.Other +
  GnomAD_initialplp$Allele.Number.South.Asian + GnomAD_initialplp$Allele.Number.Ashkenazi.Jewish 

GnomAD_initialplp$European_AlleleTotal <- GnomAD_initialplp$Allele.Number.European..Finnish. +
  GnomAD_initialplp$Allele.Number.European..non.Finnish.

GnomAD_initialplp$AA_MAF <- GnomAD_initialplp$Allele.Count.African.African.American/
  GnomAD_initialplp$Allele.Number.African.African.American

GnomAD_initialplp$LA_MAF <- GnomAD_initialplp$Allele.Count.Latino.Admixed.American/
  GnomAD_initialplp$Allele.Number.Latino.Admixed.American

GnomAD_initialplp$EA_MAF <- GnomAD_initialplp$Allele.Count.East.Asian/
  GnomAD_initialplp$Allele.Number.East.Asian

GnomAD_initialplp$SA_MAF <- GnomAD_initialplp$Allele.Count.South.Asian/
  GnomAD_initialplp$Allele.Number.South.Asian

GnomAD_initialplp$AJ_MAF <- GnomAD_initialplp$Allele.Count.Ashkenazi.Jewish/
  GnomAD_initialplp$Allele.Number.Ashkenazi.Jewish


GnomAD_initialplp$NonEuropean_MAF <- GnomAD_initialplp$NonEuropean_MinorAlleleTotal/
  GnomAD_initialplp$NonEuropean_AlleleTotal
GnomAD_initialplp$European_MAF <- GnomAD_initialplp$European_MinorAlleleTotal/
  GnomAD_initialplp$European_AlleleTotal

GnomAD_initialplp_trimmed <- GnomAD_initialplp %>% 
  select(ClinVar.Variation.ID, AlleleID, GeneSymbol, NonEuropean_MAF, European_MAF,
         AA_MAF, LA_MAF, EA_MAF, SA_MAF, AJ_MAF)

GnomAD_initialplp_trimmed$SA_MAF <- str_replace_all(GnomAD_initialplp_trimmed$SA_MAF, fixed("NaN"), "0")

#High MAF in non-Europeans
prop_LPP <- data.table(sum(GnomAD_initialplp_trimmed$NonEuropean_MAF > 1E-4 | 
      GnomAD_initialplp_trimmed$AA_MAF > 1E-4 |
      GnomAD_initialplp_trimmed$LA_MAF > 1E-4 |
      GnomAD_initialplp_trimmed$EA_MAF > 1E-4 |
      GnomAD_initialplp_trimmed$SA_MAF > 1E-4 |
      GnomAD_initialplp_trimmed$AJ_MAF > 1E-4)/
  nrow(GnomAD_initialplp_trimmed))

prop_LPP <- prop_LPP %>% rename("NonEuropean" = "V1")

#High MAF in Europeans
prop_LPP$European <- sum(GnomAD_initialplp_trimmed$European_MAF > 1E-4)/
  nrow(GnomAD_initialplp_trimmed)

prop_LPP <- data.table(t(prop_LPP))
prop_LPP$Ancestry <- c("NonEuropean", "European")

f <- ggplot(prop_LPP, aes(fill = Ancestry, x = Ancestry, y = V1))+
  geom_bar(stat = "identity", color = "black")+
  geom_errorbar(aes(x = Ancestry, ymin = V1 - 1.96*sqrt((V1*(1-V1))/441), ymax = V1 + 1.96*sqrt((V1*(1-V1))/441)),
                width = 0.25, size = 1.0)+
  scale_fill_manual(values = c("white", "dodgerblue3"))+
  xlab("Ancestry")+
  ylab("Proportion P/LP Variants MAF >1E-04")+
  theme(axis.ticks.length = unit(0.6, "cm"),
        axis.ticks = element_line(size = 1.5),
        axis.text = element_text(size = 26, family = "Arial", color = "black", face = "bold"),
        text = element_text(size = 26, family = "Arial", color = "black", face = "bold"), 
        axis.line = element_line(color = "black", size = 1.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), panel.background = element_blank(),
        legend.position = "none")

f



  #8f: Continuous MAF Analysis----
#Downgraded Variants
summary(GnomAD_downgrades_trimmed$European_MAF)
summary(GnomAD_downgrades_trimmed$NonEuropean_MAF)

downgrades_euro <- GnomAD_downgrades_trimmed %>% select(European_MAF)
downgrades_euro$ancestry_ind <- 1
downgrades_euro <- downgrades_euro %>% rename(MAF = European_MAF)

downgrades_noneuro <- GnomAD_downgrades_trimmed %>% select(NonEuropean_MAF)
downgrades_noneuro$ancestry_ind <- 0
downgrades_noneuro <- downgrades_noneuro %>% rename(MAF = NonEuropean_MAF)

downgrades_all <- rbind(downgrades_euro, downgrades_noneuro)

t.test(MAF~ancestry_ind, data = downgrades_all)
wilcox.test(MAF~ancestry_ind, data = downgrades_all)

#All initially pathogenic
summary(GnomAD_initialplp_trimmed$European_MAF)
summary(GnomAD_initialplp_trimmed$NonEuropean_MAF)

plp_euro <- GnomAD_initialplp_trimmed %>% select(European_MAF)
plp_euro$ancestry_ind <- 1
plp_euro <- plp_euro %>% rename(MAF = European_MAF)

plp_noneuro <- GnomAD_initialplp_trimmed %>% select(NonEuropean_MAF)
plp_noneuro$ancestry_ind <- 0
plp_noneuro <- plp_noneuro %>% rename(MAF = NonEuropean_MAF)

plp_all <- rbind(plp_euro, plp_noneuro)

t.test(MAF~ancestry_ind, data = plp_all)
wilcox.test(MAF~ancestry_ind, data = plp_all)
