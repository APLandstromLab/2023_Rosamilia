#Full ClinVar Processing----
#First step is an iterative process designed for use with limited computational capacity
#Repeat for each additional month of data you would like to include
#This should be done seperately for the year 2015 given different date nomenclature that year on ClinVar
GeneBank1 <- read.delim("ClinVar_variantsummary_monthX")#read in variant summary text file for a given month, publically available on ClinVar
names(GeneBank1) [1] <- "AlleleID"
GeneBank1 <- GeneBank1 %>% select(AlleleID, GeneSymbol, ClinicalSignificance, 
                                LastEvaluated, NumberSubmitters, ReviewStatus)
GeneBank1 <- data.table(distinct(GeneBank1))

GeneBank <- rbind(GeneBank, GeneBank1)

GeneBank <- data.table(distinct(GeneBank))

#Post-processing.2----
#Read in 2015 file
df2015 <- read.delim("ClinVar_variantsummary_2015")

#Split Date to Make Consistent with Other Years
df2015$Month <- substring(df2015$LastEvaluated, 4, 6)
df2015$Day <- substring(df2015$LastEvaluated, 1, 2)
df2015$Year <- substring(df2015$LastEvaluated, 8, 11) %>% as.numeric(df2015$Year)

#Read in file with all other years
dfother <- read.delim("ClinVar_variantsummary_not2015")

#Split Date
dfother$Month <- substring(dfother$LastEvaluated, 1, 3)
dfother$Day <- substring(dfother$LastEvaluated, 5, 6)
dfother$Year <- substring(dfother$LastEvaluated, 9, 12) %>% as.numeric(dfother$Year)

#Merge
GeneBank <- rbind(df2015, dfother)


#Filter
GeneBank <- GeneBank %>% select(AlleleID, GeneSymbol, ClinicalSignificance, 
                                  NumberSubmitters, ReviewStatus, Day, Month, Year)
GeneBank <- GeneBank %>% select(AlleleID, GeneSymbol, ClinicalSignificance, Day, Month, Year)
GeneBank <- data.table(distinct(GeneBank))

#Incompletes
GeneBank <- data.table(GeneBank[complete.cases(GeneBank),])

#Create New LastEvaluated Variable
GeneBank$LastEvaluated <- paste(GeneBank$Day, GeneBank$Month, GeneBank$Year)
GeneBank <- GeneBank %>% select(AlleleID, GeneSymbol, ClinicalSignificance, 
                               LastEvaluated, Year,
                               NumberSubmitters, ReviewStatus)



#Code Pathogenicity assignments
GeneBankfilt <- GeneBank
GeneBankfilt$ClinicalSignificance <- 
  ifelse(GeneBankfilt$ClinicalSignificance == "Benign;Uncertain significance", "Conflicting interpretations of pathogenicity",
         ifelse(GeneBankfilt$ClinicalSignificance == "Uncertain significance;Benign", "Conflicting interpretations of pathogenicity", 
                ifelse(GeneBankfilt$ClinicalSignificance == "Likely benign;Uncertain significance", "Conflicting interpretations of pathogenicity", 
                       ifelse(GeneBankfilt$ClinicalSignificance == "Uncertain significance;Likely benign", "Conflicting interpretations of pathogenicity",
                              ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Uncertain significance", "Conflicting interpretations of pathogenicity", 
                                     ifelse(GeneBankfilt$ClinicalSignificance == "Uncertain significance;Likely pathogenic", "Conflicting interpretations of pathogenicity",
                                            ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;Uncertain significance", "Conflicting interpretations of pathogenicity",        
                                                   ifelse(GeneBankfilt$ClinicalSignificance == "Uncertain significance;Pathogenic", "Conflicting interpretations of pathogenicity",     
                                                          ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Benign", "Conflicting interpretations of pathogenicity",
                                                                 ifelse(GeneBankfilt$ClinicalSignificance == "Benign;Likely pathogenic", "Conflicting interpretations of pathogenicity",     
                                                                        ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;Benign", "Conflicting interpretations of pathogenicity",
                                                                               ifelse(GeneBankfilt$ClinicalSignificance == "Benign;Pathogenic", "Conflicting interpretations of pathogenicity",    
                                                                                      ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Likely benign", "Conflicting interpretations of pathogenicity",   
                                                                                             ifelse(GeneBankfilt$ClinicalSignificance == "Likely benign;Likely pathogenic", "Conflicting interpretations of pathogenicity",
                                                                                                    ifelse(GeneBankfilt$ClinicalSignificance == "Likely benign;Pathogenic", "Conflicting interpretations of pathogenicity",
                                                                                                           ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;Likely Benign", "Conflicting interpretations of pathogenicity",
                                                                                                                  ifelse(GeneBankfilt$ClinicalSignificance == "Likely benign;Benign", "Benign/Likely benign",
                                                                                                                         ifelse(GeneBankfilt$ClinicalSignificance == "Benign;Likely benign", "Benign/Likely benign",
                                                                                                                                ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Pathogenic", "Pathogenic/Likely pathogenic",
                                                                                                                                       ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;Likely pathogenic", "Pathogenic/Likely pathogenic",
                                                                                                                                              ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic", "Pathogenic",
                                                                                                                                                     ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;risk factor", "Pathogenic",
                                                                                                                                                            ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;not provided", "Pathogenic",
                                                                                                                                                                   ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic;not provided;risk factor", "Pathogenic",
                                                                                                                                                                          ifelse(GeneBankfilt$ClinicalSignificance == "risk factor", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                 ifelse(GeneBankfilt$ClinicalSignificance == "not provided;risk factor", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                        ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic", "Likely pathogenic",
                                                                                                                                                                                               ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;not provided", "Likely pathogenic",
                                                                                                                                                                                                      ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;not provided;risk factor", "Likely pathogenic",
                                                                                                                                                                                                             ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;risk factor", "Likely pathogenic",
                                                                                                                                                                                                                    ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Pathogenic;risk factor", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                                                           ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Pathogenic;not provided", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                                                                  ifelse(GeneBankfilt$ClinicalSignificance == "Likely pathogenic;Pathogenic;not provided;risk factor", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                                                                         ifelse(GeneBankfilt$ClinicalSignificance == "Uncertain significance", "Uncertain significance",
                                                                                                                                                                                                                                                ifelse(GeneBankfilt$ClinicalSignificance == "Uncertain significance;not provided", "Uncertain significance",
                                                                                                                                                                                                                                                       ifelse(GeneBankfilt$ClinicalSignificance == "association", "Uncertain significance",
                                                                                                                                                                                                                                                              ifelse(GeneBankfilt$ClinicalSignificance == "Likely benign", "Likely benign",
                                                                                                                                                                                                                                                                     ifelse(GeneBankfilt$ClinicalSignificance == "Likely benign;not provided", "Likely benign",
                                                                                                                                                                                                                                                                            ifelse(GeneBankfilt$ClinicalSignificance == "Benign", "Benign",
                                                                                                                                                                                                                                                                                   ifelse(GeneBankfilt$ClinicalSignificance == "Benign;not provided", "Benign",
                                                                                                                                                                                                                                                                                          ifelse(GeneBankfilt$ClinicalSignificance == "Conflicting interpretations of pathogenicity", "Conflicting interpretations of pathogenicity",
                                                                                                                                                                                                                                                                                                 ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic/Likely pathogenic", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                                                                                                                                        ifelse(GeneBankfilt$ClinicalSignificance == "Pathogenic/Likely pathogenic, risk factor", "Pathogenic/Likely pathogenic",
                                                                                                                                                                                                                                                                                                               ifelse(GeneBankfilt$ClinicalSignificance == "Benign/Likely benign", "Benign/Likely benign", 
                                                                                                                                                                                                                                                                                                                      ifelse(GeneBankfilt$ClinicalSignificance == "not provided", "not provided",
                                                                                                                                                                                                                                                                                                                             ifelse(GeneBankfilt$ClinicalSignificance == "-", "-",
                                                                                                                                                                                                                                                                                                                                    ifelse(GeneBankfilt$ClinicalSignificance == "no interpretation for the single variant", "-",
                                                                                                                                                                                                                                                                                                                                           ifelse(GeneBankfilt$ClinicalSignificance == "not reported for simple variant", "-", 
                                                                                                                                                                                                                                                                                                                                                  ifelse(GeneBankfilt$ClinicalSignificance == "Affects", "-",
                                                                                                                                                                                                                                                                                                                                                         ifelse(GeneBankfilt$ClinicalSignificance == "drug response", "-",
                                                                                                                                                                                                                                                                                                                                                                "Conflicting interpretations of pathogenicity"))))))))))))))))))))))))))))))))))))))))))))))))))

GeneBank <- GeneBankfilt

GeneBank <- data.table(distinct(GeneBank))


#Submission Summary File----
#Repeat initial process of reading in variant summaries, but with submission summaries for additional metadata
SubBank1 <- read.delim("ClinVar_submissionsummary_yearX")
names(SubBank1) [1] <- "VariationID"
SubBank1 <- SubBank1 %>% select(VariationID, Submitter, DateLastEvaluated, 
                                ReviewStatus, CollectionMethod)
SubBank1 <- data.table(distinct(SubBank1))

SubBank <- rbind(SubBank, SubBank1)

SubBank <- data.table(distinct(SubBank))

#Reformat Dates of SubBank
SubBank$Month <- substring(SubBank$DateLastEvaluated, 1, 3)
SubBank$Day <- substring(SubBank$DateLastEvaluated, 5, 6)
SubBank$Year <- substring(SubBank$DateLastEvaluated, 9, 12) %>% as.numeric(SubBank$Year)

#Filter
SubBank <- SubBank %>% select(VariationID, Day, Month, Year, Submitter, 
                              ReviewStatus, CollectionMethod)
SubBank <- data.table(distinct(SubBank))

#Remove Incomplete Cases 
SubBank <- data.table(SubBank[complete.cases(SubBank),])

#Create New LastEvaluated Variable
SubBank$LastEvaluated <- paste(SubBank$Day, SubBank$Month, SubBank$Year)
SubBank <- SubBank %>% select(VariationID, LastEvaluated, Submitter, ReviewStatus,
                              CollectionMethod)

#Link VariationID to GeneBank----
names(Var_Allele) [1] <- "VariationID"
Var_Allele <- Var_Allele %>% select(VariationID, AlleleID)

GeneBank <- merge(GeneBank, Var_Allele, by = "AlleleID")

GeneBank <- GeneBank %>% rename("ReviewStatusHighest" = "ReviewStatus")

#Merge GeneBank and SubBank
GeneBank.2 <- left_join(GeneBank, SubBank, by = c("VariationID", "LastEvaluated"))



